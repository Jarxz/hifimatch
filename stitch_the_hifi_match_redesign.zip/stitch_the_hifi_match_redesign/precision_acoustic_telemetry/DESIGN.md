---
name: Precision Acoustic Telemetry
colors:
  surface: '#121315'
  surface-dim: '#121315'
  surface-bright: '#38393b'
  surface-container-lowest: '#0d0e10'
  surface-container-low: '#1b1c1e'
  surface-container: '#1f2022'
  surface-container-high: '#292a2c'
  surface-container-highest: '#343537'
  on-surface: '#e3e2e5'
  on-surface-variant: '#d1c5b8'
  inverse-surface: '#e3e2e5'
  inverse-on-surface: '#303033'
  outline: '#998f83'
  outline-variant: '#4d463c'
  surface-tint: '#e0c298'
  primary: '#e2c399'
  on-primary: '#402d0f'
  primary-container: '#c5a880'
  on-primary-container: '#513d1d'
  inverse-primary: '#725b38'
  secondary: '#b6c7e5'
  on-secondary: '#203148'
  secondary-container: '#394a62'
  on-secondary-container: '#a8b9d6'
  tertiary: '#5ddea9'
  on-tertiary: '#003825'
  tertiary-container: '#3cc28f'
  on-tertiary-container: '#004a33'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#fedeb2'
  primary-fixed-dim: '#e0c298'
  on-primary-fixed: '#281800'
  on-primary-fixed-variant: '#584323'
  secondary-fixed: '#d4e3ff'
  secondary-fixed-dim: '#b6c7e5'
  on-secondary-fixed: '#091c32'
  on-secondary-fixed-variant: '#374860'
  tertiary-fixed: '#7afac3'
  tertiary-fixed-dim: '#5cdda8'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005138'
  background: '#121315'
  on-background: '#e3e2e5'
  surface-variant: '#343537'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.005em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.03em
  telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  panel-gap: 0.75rem
---

## Brand & Style

The design system operates as a laboratory-grade audio engineering workbench and acoustic diagnostic suite. It prioritizes empirical physics, electrical specifications, and psychoacoustic modeling over audiophile subjectivity. The aesthetic is sober, quiet, authoritative, and strictly calibrated.

The visual style blends **Technical Minimalism** with **Industrial Laboratory Instrument Ergonomics**:
- Deep obsidian and charcoal slate structural tiers establish an optical vacuum, reducing eye fatigue during intensive acoustic analysis.
- Every pixel of information is divided into two distinct cognitive layers: **Physical Law** (empirical measurements, impedance curves, electrical power headroom, standing waves) and **Editorial Criterion** (curatorial guidelines, subjective recommendations, aesthetic pairings).
- High visual tension between technical hairline borders and tabular data arrays gives the product the feel of aerospace test equipment or benchtop oscilloscopes.

## Colors

The palette is engineered around dark slate substrates and distinct functional bands to enforce an unambiguous semantic hierarchy:

### Surface & Canvas Tokens
- **Canvas Base (`surface-base`)**: `#0B0C0E` — Total acoustic void, deepest baseline.
- **Panel Primary (`surface-panel`)**: `#14171C` — Instrument rack chassis, card bases, inspector trays.
- **Panel Elevated (`surface-elevated`)**: `#1C2027` — Hover states, modal sheets, floating measurement overlays.
- **Hairline Dividers (`border-hairline`)**: `#272C35` — 1px crisp structural divisions, grid reticles.
- **Interactive Focus / Border Active (`border-active`)**: `#3D4554` — Focused measurement fields, selected toggles.

### Brand & Editorial Accents
- **Editorial Brand Gold (`brand-gold`)**: `#C5A880` — Used strictly for product identity, authoritative chapter numbers, and curated insight labels. Deliberately desaturated to separate it from functional status ambers.
- **Editorial Meta Slate (`editorial-slate`)**: `#4E5D78` (Border/Fill Tint: `#18202C`, Foreground: `#8FA0BC`) — Explicitly identifies non-physical, subjective criteria.

### Laboratory Telemetry Semaphores (Physical Law)
Empirically calibrated status indicators with desaturated, high-clarity wavelengths:
- **Nominal / Match OK (`telemetry-nominal`)**: `#2EB886` — Safe impedance margins, stable damping factor, linear band.
- **Caution / Warning (`telemetry-caution`)**: `#D9822B` — Borderline sensitivity, high THD risk, thermal throttling zones.
- **Critical / Phase Fault (`telemetry-critical`)**: `#D14343` — Overload clipping risk, destructive room nulls, impedance dips below amplifier stability limits.
- **Inactive / Passive Reference (`telemetry-muted`)**: `#5A6577` — Reference traces, inactive channels, dormant probes.

## Typography

The typographical system enforces absolute legibility between conceptual apparatus names and measured engineering figures:

1. **Space Grotesk** serves as the primary instrument display face for section titles, channel selectors, module indices, and system architecture headers. Its geometric rigidity communicates technical discipline.
2. **Hanken Grotesk** provides an uncolored, distraction-free neutral reading experience for long-form acoustic documentation, test condition notes, and analytical summaries.
3. **JetBrains Mono** is reserved exclusively for numerical facts, telemetry outputs, scientific units (`Hz`, `dB SPL`, `Ω`, `W RMS`, `ms`, `m²`), and physical formula badges. Tabular figures (`tnum`) must remain permanently active on this font to ensure vertical numerical alignment across comparative matrices.

## Layout & Spacing

The interface follows a dense, structured workbench layout inspired by rack-mounted laboratory hardware:

### The Layout Grid
- **Desktop (>= 1280px)**: 12-column or 16-column continuous fluid telemetry grid. Modules snap cleanly along 1px divider boundaries. Gutter: `1.5rem` (24px). Exterior margins: `2rem` (32px).
- **Tablet (768px – 1279px)**: 8-column layout. Dual-pane inspection views fold into sequential modular decks. Gutter: `1rem` (16px).
- **Mobile (< 768px)**: 4-column single-stack diagnostic feed. Waveform and chamber graphs lock to a minimum 16:9 aspect ratio or switch to tabular rollouts. Gutter: `1rem` (16px).

### Structural Principles
- **Strict 4px/8px Base Rhythm**: Internal panel paddings, telemetry blocks, and meter scales increment in clean 4px subdivisions.
- **Zero-Waste Density**: Whitespace is controlled and calibrated; margins serve as thermal isolation between independent circuit diagrams and computational calculators rather than decorative void.
- **Edge-to-Edge Dividers**: Sub-panels within cards share 1px inner dividing lines (`#272C35`) rather than nested gaps, creating a contiguous instrument rack appearance.

## Elevation & Depth

This design system avoids soft, diffuse drop shadows and realistic skeuomorphic lighting. Visual depth is established through **Tonal Laminations and Low-Contrast Outlines**:

- **Ground Level (Canvas)**: `#0B0C0E` — Static void behind all instruments.
- **Tier 1 (Chassis & Structural Grid)**: `#14171C` with a continuous `1px solid #272C35` hairline outline.
- **Tier 2 (Active Measurement Trays & Inputs)**: `#1C2027` with crisp boundary states.
- **Tier 3 (Floating Inspectors & Popovers)**: `#1C2027` surrounded by a `1px solid #3D4554` border and a sharp, ultra-tight edge shadow: `0 4px 16px rgba(0, 0, 0, 0.6)`.
- **Laser Inset Channels (Gauges, Sliders, Waveforms)**: `#0B0C0E` background with a `inset 0 1px 2px rgba(0, 0, 0, 0.8)` shadow to simulate recessed digital screens embedded into anodized aluminum chassis.

## Shapes

The shape vocabulary is strictly calibrated to Level 1 (Soft / Precision Chiseled):
- Base containers, sub-panels, telemetry cards, and input fields use a microscopic radius of **4px (`0.25rem`)**, ensuring lines look razor-sharp and industrial.
- Interactive segment switches and inner pill tags utilize **2px to 4px** bounds. 
- Large modal dialogs or telemetry drawer panels scale no higher than **8px (`0.5rem`)**.
- Fully circular curves (`9999px`) are restricted exclusively to mechanical rotary knobs, radio center dots, and status semaphore beads.

## Components

### 1. Two-Layer Classification Badges
- **Physical Law Badge**: Displayed in `JetBrains Mono` at 11px uppercase. Background: `#14171C`, border: `1px solid #272C35`. Contains a 6px circular LED semaphore dot colored in `#2EB886`, `#D9822B`, or `#D14343`. Indicates indisputable acoustic/electrical realities (e.g., `IMPEDANCE MINIMA: 3.2Ω @ 140Hz`).
- **Editorial Pill Badge**: Clearly delineated with a **dashed border** `1px dashed #4E5D78` and a subtle background tint of `rgba(78, 93, 120, 0.12)`. Foreground label reads: `[ CRITERIO EDITORIAL — NO FÍSICA ]` in `#8FA0BC` using `Space Grotesk` 11px. Used alongside aesthetic synergy notes and subjective soundstage evaluations.

### 2. Telemetry Cards & Panels
Constructed on `#14171C` with `border: 1px solid #272C35` and `border-radius: 4px`. Headers feature an integrated technical breadcrumb (e.g., `SEC.04 // ACOUSTIC BOUNDARY INTERACTION`) rendered in `Space Grotesk` with letter-spacing `0.08em` and `#C5A880` gold accents. Content areas incorporate collapsible toggle carrots with monospaced parameter tables.

### 3. Segmented Pill Switches
Flush, low-profile segment controllers recessed into `#0B0C0E`. Inactive tabs render in `#8FA0BC` text without borders. The active selection illuminates with a `#1C2027` plate, a `1px solid #3D4554` rim, and crisp white/gold typography.

### 4. Input Fields & Steppers
Precision inputs designed for empirical values (e.g., Room Length `[ 6.40 ] m`, Output Impedance `[ 0.05 ] Ω`). Background: `#0B0C0E`; border: `1px solid #272C35`. Tabular monospaced text aligns right with fixed scientific suffix units displayed in muted slate `#5A6577`. On focus, the border shifts crisply to `#C5A880` or `#3D4554` with zero luminous glow.

### 5. Buttons
- **Primary Execution (Calculate, Run Trace)**: Sharp `#C5A880` background with deep `#0B0C0E` high-contrast typography, bold weight, 4px corner radius.
- **Secondary (Inspect, Export Vector)**: Background `#1C2027`, border `1px solid #272C35`, text `#8FA0BC`. On hover, border shifts to `#3D4554` and text to `#F0F2F5`.
- **System Destructive (Flush Calibration)**: Ghost button with border `1px solid rgba(209, 67, 67, 0.4)` and `#D14343` text.

### 6. Interactive Chamber Diagrams (SVG Wireframes)
Isometric and 2D orthographic room modes rendered with ultra-fine `1px` SVG vector strokes. Incident sound waves use solid `#8FA0BC` lines, room reflections render as dimmed `#272C35` dashed traces, and boundary boundary resonance hot-spots glow with desaturated `#D9822B` or `#D14343` points.