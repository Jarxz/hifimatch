import React, { useState } from 'react';
import { ScreenTab, RoomEnvironment } from '../types';

interface ARCalibracionScreenProps {
  room: RoomEnvironment;
  onUpdateRoom: (room: Partial<RoomEnvironment>) => void;
  onNavigate: (tab: ScreenTab) => void;
  lang: 'es' | 'en';
}

export const ARCalibracionScreen: React.FC<ARCalibracionScreenProps> = ({
  room,
  onUpdateRoom,
  lang,
}) => {
  const [toeInDeg, setToeInDeg] = useState<number>(15);
  const [speakerWallDist, setSpeakerWallDist] = useState<number>(0.8);

  // Rayleigh axial modes: f = c / (2 * dim)
  const c = 343.2; // m/s
  const modeL1 = Number((c / (2 * room.length)).toFixed(1));
  const modeL2 = Number((modeL1 * 2).toFixed(1));
  const modeW1 = Number((c / (2 * room.width)).toFixed(1));
  const modeW2 = Number((modeW1 * 2).toFixed(1));
  const modeH1 = Number((c / (2 * room.height)).toFixed(1));

  // Volume & Schroeder Frequency approx (assuming RT60 ~ 0.4s for typical room)
  const volume = Number((room.length * room.width * room.height).toFixed(1));
  const schroederFreq = Math.round(2000 * Math.sqrt(0.4 / Math.max(volume, 10)));

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-10 flex flex-col gap-8">
      {/* Top Header */}
      <div className="flex flex-col gap-2 border-b border-[#272c35] pb-6">
        <div className="flex items-center gap-2">
          <span className="font-label-caps text-[#e2c399] tracking-widest text-xs uppercase">
            CALIBRACIÓN ESPACIAL // ISOMÉTRICO 3D
          </span>
          <span className="text-[#4d463c]">|</span>
          <span className="font-telemetry-sm text-[11px] text-[#5ddea9]">
            FRECUENCIA SCHROEDER: {schroederFreq} Hz
          </span>
        </div>
        <h1 className="font-headline-xl text-2xl sm:text-4xl uppercase font-bold text-[#e3e2e5]">
          {lang === 'es' ? 'Simulador Acústico de Sala & Modos Propios' : 'Room Acoustics & Standing Waves Simulator'}
        </h1>
        <p className="font-body-md text-sm text-[#d1c5b8] max-w-3xl leading-relaxed">
          {lang === 'es'
            ? 'Calcula las frecuencias de resonancia modal de Rayleigh y visualiza la interacción de las ondas estacionarias con la posición de escucha y el ángulo de convergencia (toe-in).'
            : 'Computes Rayleigh axial room modes and simulates standing waves interaction with listening sweet-spot and speaker toe-in angle.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Isometric SVG Chamber */}
        <div className="lg:col-span-8 bg-[#14171c] rounded p-6 border border-[#272c35] shadow-xl flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <span className="font-label-caps text-xs text-[#e2c399] uppercase">
              {lang === 'es' ? 'REPRESENTACIÓN ISOMÉTRICA DE LA SALA' : 'ISOMETRIC ROOM SIMULATION'}
            </span>
            <div className="flex items-center gap-3 font-telemetry-sm text-[11px]">
              <span className="text-[#5ddea9]">● LP (Sweet Spot)</span>
              <span className="text-[#e2c399]">● Transductores</span>
            </div>
          </div>

          {/* SVG Visualizer */}
          <div className="h-80 w-full bg-[#0d0e10] rounded p-4 border border-[#272c35] relative flex items-center justify-center overflow-hidden">
            <svg className="w-full h-full text-[#4d463c]" fill="none" viewBox="0 0 700 350">
              {/* Isometric Room Floor */}
              <polygon
                points="100,220 350,310 600,220 350,130"
                fill="#1b1c1e"
                stroke="#272c35"
                strokeWidth="1.5"
              />
              {/* Room Walls */}
              <polygon
                points="100,220 100,80 350,170 350,310"
                fill="#14171c"
                stroke="#343537"
                strokeWidth="1"
              />
              <polygon
                points="600,220 600,80 350,170 350,310"
                fill="#1f2022"
                stroke="#343537"
                strokeWidth="1"
              />

              {/* Grid Lines on Floor */}
              <line stroke="#272c35" strokeDasharray="3 3" x1="180" x2="430" y1="190" y2="280" />
              <line stroke="#272c35" strokeDasharray="3 3" x1="270" x2="520" y1="160" y2="250" />
              <line stroke="#272c35" strokeDasharray="3 3" x1="225" x2="475" y1="265" y2="175" />

              {/* Speaker Left (with dynamic toe-in representation) */}
              <g transform="translate(240, 230)">
                <rect x="-8" y="-12" width="16" height="24" fill="#e2c399" rx="2" transform={`rotate(${-toeInDeg})`} />
                <line x1="0" y1="0" x2="80" y2="-40" stroke="#e2c399" strokeDasharray="2 2" strokeWidth="1" />
              </g>

              {/* Speaker Right */}
              <g transform="translate(460, 230)">
                <rect x="-8" y="-12" width="16" height="24" fill="#e2c399" rx="2" transform={`rotate(${toeInDeg})`} />
                <line x1="0" y1="0" x2="-80" y2="-40" stroke="#e2c399" strokeDasharray="2 2" strokeWidth="1" />
              </g>

              {/* Listener / Sweet Spot Node */}
              <circle cx="350" cy="190" r="7" fill="#5ddea9" />
              <circle cx="350" cy="190" r="16" stroke="#5ddea9" strokeDasharray="2 3" opacity="0.6" />

              {/* Standing wave interference ellipse around room center */}
              <ellipse cx="350" cy="220" rx="90" ry="30" stroke="#ffb4ab" strokeDasharray="3 5" opacity="0.7" />
              <text x="355" y="225" fill="#ffb4ab" className="font-telemetry-sm text-[10px]">
                NODO MODAL ({modeL1} Hz)
              </text>
            </svg>
          </div>

          {/* Interactive Sliders */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="flex flex-col gap-1">
              <div className="flex justify-between font-telemetry-sm text-xs">
                <span className="text-[#d1c5b8]">{lang === 'es' ? 'Ángulo Toe-In (Convergencia)' : 'Toe-In Angle'}</span>
                <span className="text-[#e2c399] font-medium">{toeInDeg}°</span>
              </div>
              <input
                type="range"
                min="0"
                max="35"
                step="1"
                value={toeInDeg}
                onChange={(e) => setToeInDeg(parseInt(e.target.value))}
                className="w-full accent-[#e2c399] cursor-pointer"
              />
            </div>

            <div className="flex flex-col gap-1">
              <div className="flex justify-between font-telemetry-sm text-xs">
                <span className="text-[#d1c5b8]">{lang === 'es' ? 'Distancia a Pared Frontal' : 'Front Wall Distance'}</span>
                <span className="text-[#e2c399] font-medium">{speakerWallDist} m</span>
              </div>
              <input
                type="range"
                min="0.3"
                max="2.0"
                step="0.1"
                value={speakerWallDist}
                onChange={(e) => setSpeakerWallDist(parseFloat(e.target.value))}
                className="w-full accent-[#e2c399] cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Rayleigh Room Modes Telemetry */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          <div className="bg-[#14171c] rounded p-6 border border-[#272c35] shadow-xl flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-[#272c35] pb-3">
              <span className="font-label-caps text-xs text-[#5ddea9] uppercase">
                {lang === 'es' ? 'MODOS AXIALES DE RAYLEIGH' : 'RAYLEIGH AXIAL MODES'}
              </span>
              <span className="font-telemetry-sm text-[10px] text-[#998f83]">
                f = (c / 2L)
              </span>
            </div>

            <div className="flex flex-col gap-2 font-telemetry-sm text-xs">
              <div className="flex justify-between py-1.5 px-2 bg-[#0d0e10] rounded border border-[#272c35]">
                <span className="text-[#998f83]">Largo Modo 1 (1,0,0):</span>
                <span className="text-[#ffb4ab] font-bold">{modeL1} Hz</span>
              </div>
              <div className="flex justify-between py-1.5 px-2 bg-[#0d0e10] rounded border border-[#272c35]">
                <span className="text-[#998f83]">Largo Modo 2 (2,0,0):</span>
                <span className="text-[#e2c399] font-bold">{modeL2} Hz</span>
              </div>
              <div className="flex justify-between py-1.5 px-2 bg-[#0d0e10] rounded border border-[#272c35]">
                <span className="text-[#998f83]">Ancho Modo 1 (0,1,0):</span>
                <span className="text-[#5ddea9] font-bold">{modeW1} Hz</span>
              </div>
              <div className="flex justify-between py-1.5 px-2 bg-[#0d0e10] rounded border border-[#272c35]">
                <span className="text-[#998f83]">Ancho Modo 2 (0,2,0):</span>
                <span className="text-[#b6c7e5] font-bold">{modeW2} Hz</span>
              </div>
              <div className="flex justify-between py-1.5 px-2 bg-[#0d0e10] rounded border border-[#272c35]">
                <span className="text-[#998f83]">Altura Modo 1 (0,0,1):</span>
                <span className="text-[#e3e2e5] font-bold">{modeH1} Hz</span>
              </div>
            </div>

            <p className="font-body-sm text-xs text-[#d1c5b8] leading-relaxed">
              {lang === 'es'
                ? `Por debajo de ${schroederFreq} Hz (Frecuencia de Schroeder), el sonido no se comporta de forma estadística sino modal. Los picos en ${modeL1}Hz y ${modeW1}Hz requieren trampas de graves en las esquinas triédricas.`
                : `Below ${schroederFreq} Hz (Schroeder Frequency), room sound is modal rather than statistical. Resonances at ${modeL1}Hz and ${modeW1}Hz warrant bass traps at corner boundaries.`}
            </p>
          </div>

          <div className="bg-[#14171c] rounded p-5 border border-[#272c35] flex flex-col gap-2 shadow-lg">
            <span className="font-label-caps text-[10px] text-[#b6c7e5] uppercase">
              [ CRITERIO EDITORIAL: TRATAMIENTO ]
            </span>
            <p className="font-body-sm text-xs text-[#d1c5b8] leading-relaxed">
              {lang === 'es'
                ? 'El 85% de la dispersión tímbrica se corrige en la sala. Gastar en cables caros antes de mitigar los modos propios en sala es una aberración económica.'
                : '85% of timbre anomalies originate in the room. Spending on esoteric cables before treating room modes is economic malpractice.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
