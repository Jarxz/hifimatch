import React from 'react';
import { ScreenTab, Speaker, Amplifier, RoomEnvironment } from '../types';
import { calculateSystemCompatibility } from '../data/physicalRules';

interface DocumentoScreenProps {
  speaker: Speaker;
  amp: Amplifier;
  room: RoomEnvironment;
  onNavigate: (tab: ScreenTab) => void;
  lang: 'es' | 'en';
}

export const DocumentoScreen: React.FC<DocumentoScreenProps> = ({
  speaker,
  amp,
  room,
  onNavigate,
  lang,
}) => {
  const verdict = calculateSystemCompatibility(speaker, amp, room);
  const reportDate = new Date().toISOString().split('T')[0];
  const auditHash = `0x88F-${speaker.brand.toUpperCase().slice(0, 3)}-${amp.model.toUpperCase().slice(0, 4)}-AES2ID`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 sm:px-6 py-10 flex flex-col gap-8">
      {/* Top Action Bar */}
      <div className="flex items-center justify-between border-b border-[#272c35] pb-4">
        <button
          type="button"
          onClick={() => onNavigate('resultado')}
          className="font-telemetry-sm text-xs text-[#d1c5b8] hover:text-[#e2c399] flex items-center gap-1 cursor-pointer"
        >
          <span className="material-symbols-outlined text-[16px]">arrow_back</span>
          <span>{lang === 'es' ? 'Volver a Resultado' : 'Back to Results'}</span>
        </button>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-4 py-2 rounded bg-[#e2c399] text-[#402d0f] font-headline-md text-xs font-semibold hover:bg-[#e0c298] cursor-pointer shadow-md"
          >
            <span className="material-symbols-outlined text-[16px]">print</span>
            <span>{lang === 'es' ? 'Imprimir / Exportar PDF' : 'Print / Export PDF'}</span>
          </button>
        </div>
      </div>

      {/* Printable Sheet Container */}
      <div className="bg-[#14171c] border border-[#272c35] rounded p-8 sm:p-12 shadow-2xl flex flex-col gap-8 text-[#e3e2e5]">
        {/* Certificate Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b-2 border-[#e2c399] pb-6">
          <div className="flex flex-col gap-1">
            <div className="flex items-baseline gap-2">
              <span className="font-headline-xl text-xl sm:text-2xl font-bold uppercase tracking-tight text-[#e3e2e5]">
                The Hifi Match
              </span>
              <span className="font-telemetry-sm text-xs text-[#e2c399] font-bold">
                SYS.LAB ACOUSTIC PLATFORM
              </span>
            </div>
            <span className="font-label-caps text-xs text-[#998f83] uppercase tracking-widest">
              CERTIFICACIÓN DETERMINISTA ELECTROACÚSTICA // IEC 60268-5 / AES-2ID
            </span>
          </div>

          <div className="flex flex-col sm:items-end font-telemetry-sm text-xs text-[#998f83]">
            <div>DOC ID: <span className="text-[#e2c399]">{auditHash}</span></div>
            <div>FECHA DE AUDITORÍA: <span className="text-[#e3e2e5]">{reportDate}</span></div>
            <div>STATUS: <span className="text-[#5ddea9]">VERIFICADO CONFORME</span></div>
          </div>
        </div>

        {/* Executive Verdict Summary */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-[#0d0e10] rounded border border-[#272c35]">
          <div className="flex flex-col">
            <span className="font-telemetry-sm text-[10px] text-[#998f83]">ÍNDICE DE ACOPLE</span>
            <span className="font-headline-xl text-3xl font-bold text-[#e2c399]">{verdict.score} / 100</span>
          </div>
          <div className="flex flex-col">
            <span className="font-telemetry-sm text-[10px] text-[#998f83]">RESERVA DINÁMICA</span>
            <span className="font-headline-xl text-3xl font-bold text-[#5ddea9]">
              {verdict.headroomDb >= 0 ? `+${verdict.headroomDb}` : verdict.headroomDb} dB
            </span>
          </div>
          <div className="flex flex-col">
            <span className="font-telemetry-sm text-[10px] text-[#998f83]">DF EFECTIVO EN BORNES</span>
            <span className="font-headline-xl text-3xl font-bold text-[#e3e2e5]">{verdict.dampingFactorEffective}</span>
          </div>
          <div className="flex flex-col">
            <span className="font-telemetry-sm text-[10px] text-[#998f83]">SPL PICO A {room.listeningDistance}M</span>
            <span className="font-headline-xl text-3xl font-bold text-[#b6c7e5]">{verdict.splAtListeningPoint} dB</span>
          </div>
        </div>

        {/* Detailed Hardware Audit Tables */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Speaker Specs */}
          <div className="flex flex-col gap-2">
            <span className="font-label-caps text-xs text-[#e2c399] uppercase border-b border-[#272c35] pb-1">
              TRANSDUCTOR DE CARGA REACTIVA
            </span>
            <div className="flex flex-col gap-1.5 font-telemetry-sm text-xs pt-1">
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">Marca y Modelo:</span>
                <span className="font-medium text-[#e3e2e5]">{speaker.brand} {speaker.model}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">Sensibilidad (2.83V @ 1m):</span>
                <span className="text-[#e3e2e5]">{speaker.sensitivity} dB SPL</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">Impedancia Nominal:</span>
                <span className="text-[#e3e2e5]">{speaker.nominalImpedance} Ω</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">Valle Mínimo Medido:</span>
                <span className="text-[#ffb4ab]">{speaker.minImpedance} Ω @ {speaker.minImpedanceFreq} Hz</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">Ángulo de Fase Peor:</span>
                <span className="text-[#e2c399]">{speaker.worstPhaseAngle}° @ {speaker.worstPhaseFreq} Hz</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">EPDR Mínimo (Fincham):</span>
                <span className="text-[#5ddea9]">{speaker.epdrMin} Ω ({speaker.epdrStatus})</span>
              </div>
            </div>
          </div>

          {/* Amplifier Specs */}
          <div className="flex flex-col gap-2">
            <span className="font-label-caps text-xs text-[#5ddea9] uppercase border-b border-[#272c35] pb-1">
              ETAPA DE POTENCIA / ALIMENTACIÓN
            </span>
            <div className="flex flex-col gap-1.5 font-telemetry-sm text-xs pt-1">
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">Marca y Modelo:</span>
                <span className="font-medium text-[#e3e2e5]">{amp.brand} {amp.model}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">Topología de Circuito:</span>
                <span className="text-[#e3e2e5]">{amp.topology}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">Potencia Continua @ 8Ω:</span>
                <span className="text-[#e3e2e5]">{amp.power8Ohm} W RMS</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">Potencia Continua @ 4Ω:</span>
                <span className="text-[#5ddea9]">{amp.power4Ohm} W RMS</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">Factor D.F. @ 1kHz:</span>
                <span className="text-[#e3e2e5]">&gt; {amp.dampingFactor}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1f2022]">
                <span className="text-[#998f83]">Capacidad de Corriente Pico:</span>
                <span className="text-[#e2c399]">{amp.peakCurrent} A</span>
              </div>
            </div>
          </div>
        </div>

        {/* Environmental & Room Specs */}
        <div className="bg-[#0d0e10] p-4 rounded border border-[#272c35] flex flex-col gap-2">
          <span className="font-label-caps text-xs text-[#b6c7e5] uppercase">
            PARÁMETROS DEL RECINTO AUDITADO
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-telemetry-sm text-xs">
            <div>
              <span className="text-[#998f83]">Dimensiones:</span>
              <div className="text-[#e3e2e5] font-medium">{room.length}m × {room.width}m × {room.height}m</div>
            </div>
            <div>
              <span className="text-[#998f83]">Volumen Recinto:</span>
              <div className="text-[#e3e2e5] font-medium">{(room.length * room.width * room.height).toFixed(1)} m³</div>
            </div>
            <div>
              <span className="text-[#998f83]">Distancia Escucha:</span>
              <div className="text-[#e3e2e5] font-medium">{room.listeningDistance} m</div>
            </div>
            <div>
              <span className="text-[#998f83]">Cable Altavoz:</span>
              <div className="text-[#e3e2e5] font-medium">{room.cableLength}m (AWG {room.cableGaugeAWG})</div>
            </div>
          </div>
        </div>

        {/* Laboratory Stamp & Signature Block */}
        <div className="flex flex-col sm:flex-row items-center justify-between pt-6 border-t border-[#272c35] text-xs font-telemetry-sm text-[#998f83] gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded border border-[#5ddea9] flex items-center justify-center text-[#5ddea9] font-bold text-[10px] text-center uppercase p-1">
              AES-2ID PASS
            </div>
            <div>
              <div className="text-[#e3e2e5] font-medium">DICTAMEN FÍSICO AUTOMATIZADO</div>
              <div>AUDITADO MEDIANTE THE HIFIMATCH LABORATORY ENGINE</div>
            </div>
          </div>

          <div className="text-right">
            <div>CHECKSUM SHA-256: 3c9b8e21...fa92</div>
            <div className="text-[#e2c399]">VALIDADO CON NORMAS IEC 60268-5</div>
          </div>
        </div>
      </div>
    </div>
  );
};
