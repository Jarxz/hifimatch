import React, { useState } from 'react';
import { ScreenTab } from '../types';
import { SPEAKERS_DATABASE, AMPLIFIERS_DATABASE, PRESET_CHAINS } from '../data/equipment';
import { calculateSystemCompatibility } from '../data/physicalRules';

interface PortadaScreenProps {
  onNavigate: (tab: ScreenTab) => void;
  lang: 'es' | 'en';
  onSelectChainForConfig?: (speakerId: string, ampId: string) => void;
}

export const PortadaScreen: React.FC<PortadaScreenProps> = ({
  onNavigate,
  lang,
  onSelectChainForConfig,
}) => {
  const [selectedChainId, setSelectedChainId] = useState<string>('chain-1');

  // Active chain lookup
  const activeChain = PRESET_CHAINS.find((c) => c.id === selectedChainId) || PRESET_CHAINS[0];
  const activeSpeaker =
    SPEAKERS_DATABASE.find((s) => s.id === activeChain.speakerId) || SPEAKERS_DATABASE[0];
  const activeAmp =
    AMPLIFIERS_DATABASE.find((a) => a.id === activeChain.ampId) || AMPLIFIERS_DATABASE[0];

  // Live calculation
  const verdict = calculateSystemCompatibility(activeSpeaker, activeAmp, {
    length: 5.8,
    width: 4.2,
    height: 2.8,
    listeningDistance: 3.2,
    treatmentType: 'Typical Living Room',
    cableLength: 3.0,
    cableGaugeAWG: 12,
  });

  const handleSelectChain = (chainId: string) => {
    setSelectedChainId(chainId);
    const chain = PRESET_CHAINS.find((c) => c.id === chainId);
    if (chain && onSelectChainForConfig) {
      onSelectChainForConfig(chain.speakerId, chain.ampId);
    }
  };

  return (
    <div className="flex flex-col w-full">
      {/* HERO MASTER INSTRUMENT SECTION */}
      <section className="relative w-full overflow-hidden bg-[#0d0e10] py-12 px-4 sm:px-6 border-b border-[#272c35]">
        {/* Ambient Chamber Wireframe Canvas Background */}
        <div className="absolute inset-0 pointer-events-none opacity-20 select-none overflow-hidden flex items-center justify-center">
          <svg
            className="w-[1400px] h-[900px] text-[#4d463c]"
            fill="none"
            viewBox="0 0 1000 600"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Room Grid Floor Isometric */}
            <path
              d="M100 450 L500 580 L900 450 L500 320 Z"
              stroke="currentColor"
              strokeDasharray="3 6"
              strokeWidth="0.75"
            />
            <path
              d="M200 420 L500 515 L800 420"
              stroke="currentColor"
              strokeDasharray="2 4"
              strokeWidth="0.5"
            />
            <path
              d="M300 390 L500 450 L700 390"
              stroke="currentColor"
              strokeDasharray="2 4"
              strokeWidth="0.5"
            />
            <path
              d="M400 355 L500 385 L600 355"
              stroke="currentColor"
              strokeDasharray="2 4"
              strokeWidth="0.5"
            />
            {/* Room Boundaries & Axial Planes */}
            <path d="M100 450 V 150 L500 40 V 320 Z" stroke="currentColor" strokeWidth="0.75" />
            <path d="M900 450 V 150 L500 40" stroke="currentColor" strokeWidth="0.75" />
            <path
              d="M100 150 L500 240 L900 150"
              stroke="currentColor"
              strokeDasharray="4 8"
              strokeWidth="0.5"
            />
            <path d="M500 240 V 580" stroke="currentColor" strokeDasharray="4 8" strokeWidth="0.5" />
            {/* Speaker Source Nodes */}
            <circle className="fill-[#e2c399]" cx="340" cy="380" r="4" />
            <circle className="fill-[#e2c399]" cx="660" cy="380" r="4" />
            {/* Dispersion Wavefronts (Incident) */}
            <path d="M340 380 Q 420 340 480 300" stroke="#b6c7e5" strokeLinecap="round" strokeWidth="1" />
            <path d="M340 380 Q 470 390 580 410" stroke="#b6c7e5" strokeLinecap="round" strokeWidth="1" />
            <path
              d="M340 380 Q 300 430 260 480"
              stroke="#b6c7e5"
              strokeDasharray="2 3"
              strokeWidth="0.75"
            />
            <path d="M660 380 Q 580 340 520 300" stroke="#b6c7e5" strokeLinecap="round" strokeWidth="1" />
            <path d="M660 380 Q 530 390 420 410" stroke="#b6c7e5" strokeLinecap="round" strokeWidth="1" />
            {/* Interference Hotspots & Eigenmodes */}
            <circle
              cx="500"
              cy="410"
              opacity="0.4"
              r="32"
              stroke="#5ddea9"
              strokeDasharray="2 4"
              strokeWidth="0.75"
            />
            <circle cx="500" cy="410" opacity="0.6" r="12" stroke="#5ddea9" strokeWidth="0.75" />
            <circle className="fill-[#5ddea9]" cx="500" cy="410" r="2.5" />
            {/* Pressure Wave Nodes */}
            <ellipse
              cx="500"
              cy="240"
              rx="90"
              ry="25"
              stroke="#e2c399"
              strokeDasharray="3 5"
              strokeWidth="0.5"
            />
            <ellipse
              cx="500"
              cy="240"
              opacity="0.3"
              rx="180"
              ry="50"
              stroke="#e2c399"
              strokeDasharray="4 8"
              strokeWidth="0.5"
            />
            {/* Vector Labels */}
            <text
              className="font-telemetry-sm text-[9px] tracking-widest uppercase"
              fill="currentColor"
              x="325"
              y="405"
            >
              SRC.L [1.8m SPL-0]
            </text>
            <text
              className="font-telemetry-sm text-[9px] tracking-widest uppercase"
              fill="currentColor"
              x="645"
              y="405"
            >
              SRC.R [1.8m SPL-0]
            </text>
            <text
              className="font-telemetry-sm text-[9px] tracking-widest uppercase"
              fill="#5ddea9"
              x="475"
              y="435"
            >
              LP.0 (MODE 63Hz)
            </text>
          </svg>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto flex flex-col gap-8">
          {/* Upper Telemetry Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-[#1f2022] font-telemetry-sm text-[11px] text-[#e2c399] uppercase border border-[#272c35]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#e2c399] animate-pulse" />
                SYS: CORE v2.4.0
              </span>
              <span className="font-telemetry-sm text-[11px] text-[#4d463c]">/</span>
              <span className="font-telemetry-sm text-[11px] text-[#d1c5b8] uppercase tracking-wider">
                LABORATORY ENGINE
              </span>
            </div>
            <div className="flex items-center gap-3 font-telemetry-sm text-[11px] text-[#998f83]">
              <span className="hidden md:inline">IEC 60268-5 / AES-2ID CALIBRATED</span>
              <span className="text-[#e2c399] font-medium">REALTIME COMPLIANCE</span>
            </div>
          </div>

          {/* Main Headline Block */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-8 flex flex-col gap-4">
              {/* Sub-badge Category */}
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded bg-[#1f2022] font-label-caps text-[#e2c399] uppercase tracking-widest border border-[#343537]">
                  {lang === 'es'
                    ? 'Arquitectura Acústica • Determinista'
                    : 'Acoustic Architecture • Deterministic'}
                </span>
              </div>

              {/* Main Title */}
              <h1 className="font-headline-xl text-[40px] sm:text-[54px] lg:text-[68px] leading-[1.05] tracking-tight uppercase font-bold text-[#e3e2e5]">
                THE HIFI <span className="text-[#e2c399]">MATCH</span>
              </h1>

              {/* Tagline */}
              <p className="font-headline-lg text-lg sm:text-xl text-[#e2c399] tracking-tight font-medium max-w-2xl">
                {lang === 'es'
                  ? 'Basado en física, specs medidos — tú escuchas y decides.'
                  : 'Based on empirical physics, measured specs — you listen and decide.'}
              </p>

              {/* Precision Subtext */}
              <p className="font-body-lg text-sm sm:text-base text-[#d1c5b8] max-w-2xl leading-relaxed">
                {lang === 'es'
                  ? 'Motor de compatibilidad electroacústica para sistemas de audio de alta fidelidad. Analiza el acople eléctrico, reserva de potencia y acústica de sala según leyes físicas refutables.'
                  : 'Electroacoustic matching engine for high-fidelity audio chains. Analyzes electrical coupling, power headroom, and room acoustics strictly according to refutable physical laws.'}
              </p>

              {/* CTA Primary / Secondary Hub */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  type="button"
                  onClick={() => onNavigate('configurar')}
                  id="cta-analizar-sistema"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded bg-[#e2c399] text-[#402d0f] font-headline-md text-sm sm:text-base font-semibold hover:bg-[#e0c298] transition-all shadow-md active:translate-y-0.5 cursor-pointer"
                >
                  <span>{lang === 'es' ? 'Analizar un sistema' : 'Analyze a system'}</span>
                  <span className="material-symbols-outlined text-[20px]">equalizer</span>
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('guia')}
                  id="cta-explorar-guia"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded bg-[#292a2c] text-[#b6c7e5] hover:text-[#e3e2e5] hover:bg-[#38393b] transition-all font-headline-md text-sm sm:text-base font-medium border border-[#3d4554] cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[20px]">menu_book</span>
                  <span>{lang === 'es' ? 'Explorar guía de física' : 'Explore physics guide'}</span>
                </button>
              </div>
            </div>

            {/* Telemetry Live Feed Capsule (Right Side Asymmetry) */}
            <div className="lg:col-span-4 flex flex-col gap-3 bg-[#1b1c1e] rounded p-4 shadow-xl border border-[#272c35]">
              <div className="flex items-center justify-between pb-1 border-b border-[#272c35]">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#5ddea9]" />
                  <span className="font-label-caps uppercase tracking-wider text-[#e3e2e5]">
                    {lang === 'es' ? 'ESTADO DEL DIAGNÓSTICO' : 'DIAGNOSTIC STATUS'}
                  </span>
                </div>
                <span className="font-telemetry-sm text-[#e2c399]">ID: 0x88F-AES</span>
              </div>

              {/* Mini Sparkline Vector */}
              <div className="h-28 w-full bg-[#0d0e10] rounded p-2 flex flex-col justify-between border border-[#272c35]">
                <div className="flex justify-between font-telemetry-sm text-[10px] text-[#998f83]">
                  <span>IMPEDANCIA CURVA Z(ω)</span>
                  <span className="text-[#5ddea9]">
                    MIN {activeSpeaker.minImpedance}Ω @ {activeSpeaker.minImpedanceFreq}Hz
                  </span>
                </div>
                <svg className="w-full h-16 text-[#e2c399]" fill="none" preserveAspectRatio="none" viewBox="0 0 240 60">
                  <line stroke="currentColor" strokeDasharray="2 4" strokeOpacity="0.1" x1="0" x2="240" y1="15" y2="15" />
                  <line stroke="currentColor" strokeDasharray="2 4" strokeOpacity="0.1" x1="0" x2="240" y1="35" y2="35" />
                  <path
                    d="M0 45 C 30 50, 45 10, 60 12 C 75 14, 90 52, 110 52 C 140 52, 160 38, 190 32 C 210 28, 225 15, 240 18"
                    stroke="#e2c399"
                    strokeLinecap="round"
                    strokeWidth="2"
                  />
                  <path
                    d="M0 45 C 30 50, 45 10, 60 12 C 75 14, 90 52, 110 52 C 140 52, 160 38, 190 32 C 210 28, 225 15, 240 18 L240 60 L0 60 Z"
                    fill="#e2c399"
                    fillOpacity="0.08"
                  />
                  <circle className="fill-[#5ddea9]" cx="110" cy="52" r="3" />
                </svg>
                <div className="flex justify-between font-telemetry-sm text-[10px] text-[#4d463c]">
                  <span>20 Hz</span>
                  <span>1 kHz</span>
                  <span>20 kHz</span>
                </div>
              </div>

              {/* Micro specs checklist */}
              <div className="flex flex-col gap-1.5 pt-1 font-telemetry-sm text-[11px]">
                <div className="flex justify-between py-1 bg-[#1f2022] px-2 rounded">
                  <span className="text-[#d1c5b8]">
                    {lang === 'es' ? 'Reserva dinámica pico' : 'Peak dynamic headroom'}
                  </span>
                  <span className="text-[#e3e2e5] font-medium">
                    {verdict.headroomDb >= 0 ? `+${verdict.headroomDb} dB RMS` : `${verdict.headroomDb} dB RMS`}
                  </span>
                </div>
                <div className="flex justify-between py-1 bg-[#1f2022] px-2 rounded">
                  <span className="text-[#d1c5b8]">
                    {lang === 'es' ? 'Factor amortiguamiento (D.F.)' : 'Damping factor (D.F.)'}
                  </span>
                  <span className="text-[#5ddea9] font-medium">
                    {verdict.dampingFactorEffective} (&gt;20 req.)
                  </span>
                </div>
                <div className="flex justify-between py-1 bg-[#1f2022] px-2 rounded">
                  <span className="text-[#d1c5b8]">
                    {lang === 'es' ? 'Sensibilidad neta a 3.4m' : 'Net sensitivity at 3.4m'}
                  </span>
                  <span className="text-[#e3e2e5] font-medium">
                    {verdict.splAtListeningPoint} dB SPL
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* INSTRUMENT COUNTER GRID (3 TILES) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
            {/* Tile 1: Equipos Curados */}
            <div className="flex flex-col justify-between bg-[#1f2022] rounded p-6 shadow-md transition-all hover:bg-[#292a2c] border border-[#272c35]">
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="font-telemetry-sm text-[11px] text-[#998f83] uppercase tracking-wider">
                    {lang === 'es' ? 'BANCO DE DATOS INSTRUMENTAL' : 'INSTRUMENTAL DATABASE'}
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#0d0e10] text-[#5ddea9] font-telemetry-sm text-[10px] uppercase font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#5ddea9]" />
                    {lang === 'es' ? 'Mediciones Verificadas' : 'Verified Specs'}
                  </span>
                </div>
                <div className="flex items-baseline gap-2 pt-1">
                  <span className="font-headline-xl text-[44px] leading-none font-bold text-[#e3e2e5]">
                    182
                  </span>
                  <span className="font-headline-md text-lg text-[#e2c399] font-medium">
                    {lang === 'es' ? 'Equipos' : 'Components'}
                  </span>
                </div>
                <p className="font-body-sm text-xs text-[#d1c5b8] pt-1 leading-relaxed">
                  {lang === 'es'
                    ? 'Perfiles electroacústicos completos con curvas reales de impedancia y fase reactiva: KEF, B&W, Focal, Wilson Audio, McIntosh, Hegel, Chord, dCS, Naim y Rega.'
                    : 'Complete electroacoustic profiles with measured impedance curves and reactive phase angles: KEF, B&W, Focal, Wilson Audio, McIntosh, Hegel, Chord, dCS, Naim, and Rega.'}
                </p>
              </div>
              <div className="flex flex-wrap gap-1.5 pt-4">
                <span className="px-2 py-0.5 rounded bg-[#0d0e10] font-telemetry-sm text-[10px] text-[#998f83]">
                  KEF Meta
                </span>
                <span className="px-2 py-0.5 rounded bg-[#0d0e10] font-telemetry-sm text-[10px] text-[#998f83]">
                  B&W D4
                </span>
                <span className="px-2 py-0.5 rounded bg-[#0d0e10] font-telemetry-sm text-[10px] text-[#998f83]">
                  Hegel H590
                </span>
                <span className="px-2 py-0.5 rounded bg-[#0d0e10] font-telemetry-sm text-[10px] text-[#998f83]">
                  McIntosh MC
                </span>
              </div>
            </div>

            {/* Tile 2: Reglas Físicas Deterministas */}
            <div className="flex flex-col justify-between bg-[#1f2022] rounded p-6 shadow-md transition-all hover:bg-[#292a2c] border border-[#272c35]">
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="font-telemetry-sm text-[11px] text-[#998f83] uppercase tracking-wider">
                    {lang === 'es' ? 'COMPUTACIÓN DETERMINISTA' : 'DETERMINISTIC COMPUTATION'}
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#0d0e10] text-[#e2c399] font-telemetry-sm text-[10px] uppercase font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#e2c399]" />
                    ISO/IEC Specs
                  </span>
                </div>
                <div className="flex items-baseline gap-2 pt-1">
                  <span className="font-headline-xl text-[44px] leading-none font-bold text-[#e3e2e5]">
                    46
                  </span>
                  <span className="font-headline-md text-lg text-[#e2c399] font-medium">
                    {lang === 'es' ? 'Reglas Físicas' : 'Physical Laws'}
                  </span>
                </div>
                <p className="font-body-sm text-xs text-[#d1c5b8] pt-1 leading-relaxed">
                  {lang === 'es'
                    ? 'Ecuaciones analíticas sin aproximaciones arbitrarias: Ley de Ohm compleja, ley del inverso del cuadrado, modos axiales/tangenciales de Rayleigh y factor de amortiguamiento crítico.'
                    : 'Analytical equations without arbitrary guessing: Complex Ohm law, inverse square law, Rayleigh axial/tangential modes, and critical damping factor.'}
                </p>
              </div>
              <div className="flex flex-col gap-1.5 pt-4 font-telemetry-sm text-[11px] text-[#b6c7e5]">
                <div className="flex items-center justify-between bg-[#0d0e10] px-2 py-1 rounded">
                  <span>V(t) = I(t) × |Z|</span>
                  <span className="text-[#4d463c] font-normal">Ohm Reactivo</span>
                </div>
                <div className="flex items-center justify-between bg-[#0d0e10] px-2 py-1 rounded">
                  <span>f = (c/2) √((p/L)²+(q/W)²+(r/H)²)</span>
                  <span className="text-[#4d463c] font-normal">Rayleigh</span>
                </div>
              </div>
            </div>

            {/* Tile 3: 0% Opiniones Subjetivas */}
            <div className="flex flex-col justify-between bg-[#1f2022] rounded p-6 shadow-md transition-all hover:bg-[#292a2c] border border-[#272c35]">
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="font-telemetry-sm text-[11px] text-[#998f83] uppercase tracking-wider">
                    {lang === 'es' ? 'POSTURA AUDIÓFILA' : 'AUDIOPHILE STANCE'}
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#0d0e10] text-[#b6c7e5] font-telemetry-sm text-[10px] uppercase font-medium">
                    {lang === 'es' ? 'Neutralidad Absoluta' : 'Absolute Neutrality'}
                  </span>
                </div>
                <div className="flex items-baseline gap-2 pt-1">
                  <span className="font-headline-xl text-[44px] leading-none font-bold text-[#e3e2e5]">
                    0%
                  </span>
                  <span className="font-headline-md text-lg text-[#e2c399] font-medium">
                    {lang === 'es' ? 'Subjetividad' : 'Subjectivity'}
                  </span>
                </div>
                <p className="font-body-sm text-xs text-[#d1c5b8] pt-1 leading-relaxed">
                  {lang === 'es'
                    ? 'Ausencia deliberada de adjetivos audiófilos pseudocientíficos: prohibidos términos como “cálido”, “brillante”, “musical” o “aireado”.'
                    : 'Deliberate ban on pseudo-scientific audiophile buzzwords: prohibited terms include "warm", "bright", "musical", or "airy".'}
                </p>
              </div>
              <div className="pt-4">
                <div className="px-3 py-2 rounded bg-[#0d0e10] text-[#b6c7e5] font-label-caps text-[10px] uppercase tracking-wider flex items-center gap-2 border border-[#272c35]">
                  <span className="material-symbols-outlined text-[16px] text-[#e2c399]">
                    verified_user
                  </span>
                  <span>
                    {lang === 'es'
                      ? 'Criterio editorial transparente, nunca disfrazado de física'
                      : 'Transparent editorial criterion, never disguised as physics'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* BANNER DE SEPARACIÓN DE CAPAS: FÍSICA VS CRITERIO EDITORIAL */}
      <section className="w-full bg-[#1b1c1e] py-12 px-4 sm:px-6 border-b border-[#272c35]">
        <div className="max-w-7xl mx-auto flex flex-col gap-8">
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="flex flex-col gap-1">
              <span className="font-label-caps uppercase text-[#e2c399] tracking-widest text-[11px]">
                {lang === 'es' ? 'TAXONOMÍA EPISTEMOLÓGICA' : 'EPISTEMOLOGICAL TAXONOMY'}
              </span>
              <h2 className="font-headline-xl text-2xl sm:text-3xl uppercase text-[#e3e2e5] font-bold">
                {lang === 'es'
                  ? 'Dos Capas de Información. Cero Confusión.'
                  : 'Two Layers of Information. Zero Confusion.'}
              </h2>
            </div>
            <p className="font-body-md text-xs sm:text-sm text-[#d1c5b8] max-w-lg leading-relaxed">
              {lang === 'es'
                ? 'Un principio innegociable en The Hifi Match: toda recomendación o dato está estrictamente aislado en su respectivo estrato de validez.'
                : 'A non-negotiable principle in The Hifi Match: every measurement and recommendation is strictly segregated into its valid stratum.'}
            </p>
          </div>

          {/* Comparative Two-Column Deck */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Layer 1: Physical Law */}
            <div className="flex flex-col gap-4 bg-[#1f2022] rounded p-6 shadow-md border border-[#272c35]">
              <div className="flex items-center justify-between pb-2 border-b border-[#272c35]">
                <div className="flex items-center gap-2.5">
                  <span className="w-3 h-3 rounded-full bg-[#5ddea9]" />
                  <span className="font-headline-md text-base text-[#e3e2e5] font-semibold uppercase">
                    {lang === 'es' ? 'Capa 01: Ley Física' : 'Layer 01: Physical Law'}
                  </span>
                </div>
                <span className="px-2 py-0.5 rounded bg-[#0d0e10] font-telemetry-sm text-[10px] text-[#5ddea9] uppercase font-medium">
                  {lang === 'es' ? '100% Determinista' : '100% Deterministic'}
                </span>
              </div>
              <p className="font-body-md text-xs sm:text-sm text-[#d1c5b8]">
                {lang === 'es'
                  ? 'Resultados auditables y refutables mediante instrumental de laboratorio (Audio Precision, Klippel NFS, micrófonos de campo difuso IEC).'
                  : 'Auditable and refutable findings verified via laboratory instruments (Audio Precision, Klippel NFS, IEC diffuse-field microphones).'}
              </p>

              <div className="flex flex-col gap-2.5 pt-1">
                {/* Tri-color Semaphore Indicators */}
                <div className="flex items-start gap-3 p-3 bg-[#0d0e10] rounded border border-[#272c35]">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#5ddea9] mt-1 shrink-0" />
                  <div className="flex flex-col">
                    <span className="font-headline-md text-xs text-[#5ddea9] uppercase font-medium">
                      {lang === 'es' ? 'Verde / Conforme' : 'Green / Compliant'}
                    </span>
                    <span className="font-body-sm text-[11px] text-[#d1c5b8]">
                      {lang === 'es'
                        ? 'El amplificador suministra corriente suficiente a la impedancia mínima Z_min con margen térmico > 3 dB.'
                        : 'Amplifier supplies ample current at minimum impedance Z_min with thermal headroom > 3 dB.'}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-[#0d0e10] rounded border border-[#272c35]">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#e2c399] mt-1 shrink-0" />
                  <div className="flex flex-col">
                    <span className="font-headline-md text-xs text-[#e2c399] uppercase font-medium">
                      {lang === 'es' ? 'Ámbar / En Límite Reactivo' : 'Amber / At Reactive Boundary'}
                    </span>
                    <span className="font-body-sm text-[11px] text-[#d1c5b8]">
                      {lang === 'es'
                        ? 'La fase reactiva cae bajo −45° coincidiendo con valles de impedancia. Riesgo de distorsión transitoria armónica (THD).'
                        : 'Reactive phase drops below -45° at impedance valleys. Risk of transient harmonic distortion (THD).'}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-[#0d0e10] rounded border border-[#272c35]">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#ffb4ab] mt-1 shrink-0" />
                  <div className="flex flex-col">
                    <span className="font-headline-md text-xs text-[#ffb4ab] uppercase font-medium">
                      {lang === 'es' ? 'Rojo / Infracción Física' : 'Red / Physical Violation'}
                    </span>
                    <span className="font-body-sm text-[11px] text-[#d1c5b8]">
                      {lang === 'es'
                        ? 'Insuficiencia de tensión de raíl, clipping severo inminente antes de alcanzar 85 dB SPL en el punto de escucha.'
                        : 'Rail voltage starvation, impending hard clipping before attaining 85 dB SPL at listening point.'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <span className="font-telemetry-sm text-[10px] text-[#998f83]">
                  {lang === 'es'
                    ? 'Cálculos ejecutados en el cliente • Ninguna intervención humana en los dictámenes'
                    : 'Calculations run client-side • Zero human subjectivity in findings'}
                </span>
              </div>
            </div>

            {/* Layer 2: Editorial Criterion */}
            <div className="flex flex-col gap-4 bg-[#1f2022] rounded p-6 shadow-md border border-[#272c35]">
              <div className="flex items-center justify-between pb-2 border-b border-[#272c35]">
                <div className="flex items-center gap-2.5">
                  <span className="w-3 h-3 rounded-full bg-[#b6c7e5]" />
                  <span className="font-headline-md text-base text-[#e3e2e5] font-semibold uppercase">
                    {lang === 'es' ? 'Capa 02: Criterio Editorial' : 'Layer 02: Editorial Criterion'}
                  </span>
                </div>
                <span className="px-2 py-0.5 rounded bg-[#0d0e10] font-telemetry-sm text-[10px] text-[#b6c7e5] uppercase font-medium">
                  {lang === 'es' ? 'Metodología Abierta' : 'Open Methodology'}
                </span>
              </div>
              <p className="font-body-md text-xs sm:text-sm text-[#d1c5b8]">
                {lang === 'es'
                  ? 'Decisiones de diseño, umbrales de seguridad acústica y ponderaciones psicoacústicas seleccionadas por el equipo técnico del laboratorio.'
                  : 'Design choices, acoustic safety thresholds, and psychoacoustic weightings curated by the lab engineering team.'}
              </p>

              <div className="flex flex-col gap-2.5 pt-1">
                {/* Pill Badging Showcase */}
                <div className="p-3 bg-[#0d0e10] rounded flex flex-col gap-1 border border-[#272c35]">
                  <div className="flex items-center gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-[#1f2022] text-[#b6c7e5] font-label-caps text-[9px] uppercase border border-[#394a62]">
                      [ CRITERIO EDITORIAL — NO FÍSICA ]
                    </span>
                    <span className="font-telemetry-sm text-[11px] text-[#998f83]">Umbral SPL 85 dBA</span>
                  </div>
                  <p className="font-body-sm text-[11px] text-[#d1c5b8]">
                    {lang === 'es'
                      ? 'Adoptamos la norma AES20 de 85 dBA continuo con 14 dB de headroom musical como estándar objetivo de audición de referencia sin daño coclear.'
                      : 'We adhere to AES20 standard of 85 dBA continuous with 14 dB musical headroom as the baseline without cochlear fatigue.'}
                  </p>
                </div>

                <div className="p-3 bg-[#0d0e10] rounded flex flex-col gap-1 border border-[#272c35]">
                  <div className="flex items-center gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-[#1f2022] text-[#b6c7e5] font-label-caps text-[9px] uppercase border border-[#394a62]">
                      [ CRITERIO EDITORIAL — NO FÍSICA ]
                    </span>
                    <span className="font-telemetry-sm text-[11px] text-[#998f83]">Margen Factor D.F. &gt; 20</span>
                  </div>
                  <p className="font-body-sm text-[11px] text-[#d1c5b8]">
                    {lang === 'es'
                      ? 'Fijamos el límite de audibilidad del factor de amortiguamiento en 20 para el conjunto amplificador + cableado de cobre OFC de 2.5 mm².'
                      : 'Audibility threshold for damping factor is set to 20 for amplifier + 2.5mm² OFC copper speaker cabling.'}
                  </p>
                </div>

                <div className="p-3 bg-[#0d0e10] rounded flex flex-col gap-1 border border-[#272c35]">
                  <div className="flex items-center gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-[#1f2022] text-[#b6c7e5] font-label-caps text-[9px] uppercase border border-[#394a62]">
                      [ CRITERIO EDITORIAL — NO FÍSICA ]
                    </span>
                    <span className="font-telemetry-sm text-[11px] text-[#998f83]">Prioridad de Inversión</span>
                  </div>
                  <p className="font-body-sm text-[11px] text-[#d1c5b8]">
                    {lang === 'es'
                      ? 'Sugerencia arquitectónica: la sala y los transductores representan el 85% de la dispersión de respuesta en frecuencia; la amplificación, el 15%.'
                      : 'Architectural ratio: the room and transducers govern 85% of frequency response variance; electronics govern 15%.'}
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <span className="font-telemetry-sm text-[10px] text-[#b6c7e5]">
                  {lang === 'es'
                    ? 'Declarado explícitamente en cada pantalla • Modificable por el usuario en calibración'
                    : 'Explicitly flagged on every screen • User-adjustable in calibration settings'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* QUICK SYSTEM PREVIEW / LAB CONSOLE */}
      <section className="w-full bg-[#0d0e10] py-12 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col gap-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <span className="font-label-caps text-[#e2c399] tracking-widest text-[11px] uppercase">
                TEST RACK DEMO
              </span>
              <h3 className="font-headline-lg text-xl sm:text-2xl uppercase text-[#e3e2e5] font-semibold">
                {lang === 'es'
                  ? 'Inspección Inmediata de Parejas Electroacústicas'
                  : 'Instant Inspection of Electroacoustic Pairs'}
              </h3>
            </div>
            {/* Chain Selector Tabs */}
            <div className="flex flex-wrap items-center gap-1.5 bg-[#1f2022] rounded p-1 font-telemetry-sm text-xs border border-[#272c35]">
              {PRESET_CHAINS.map((chain) => (
                <button
                  key={chain.id}
                  type="button"
                  onClick={() => handleSelectChain(chain.id)}
                  id={`preset-btn-${chain.id}`}
                  className={`px-3 py-1.5 rounded transition-all cursor-pointer ${
                    selectedChainId === chain.id
                      ? 'bg-[#292a2c] text-[#e2c399] font-medium border border-[#4d463c]'
                      : 'text-[#d1c5b8] hover:text-[#e3e2e5]'
                  }`}
                >
                  {chain.name}
                </button>
              ))}
            </div>
          </div>

          {/* Live Mock Workbench Row */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 bg-[#14171c] rounded p-6 shadow-lg border border-[#272c35]">
            {/* Transducer Unit */}
            <div className="lg:col-span-4 flex flex-col gap-3 bg-[#1b1c1e] rounded p-4 border border-[#272c35]">
              <div className="flex items-center justify-between">
                <span className="font-label-caps text-[#d1c5b8] uppercase text-[10px]">
                  {lang === 'es' ? 'ALTAVOZ / CARGA REACTIVA' : 'LOUDSPEAKER / REACTIVE LOAD'}
                </span>
                <span className="px-1.5 py-0.5 rounded bg-[#0d0e10] text-[#5ddea9] font-telemetry-sm text-[10px]">
                  VERIFICADO
                </span>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="font-headline-md text-base text-[#e3e2e5] font-semibold truncate">
                  {activeSpeaker.brand} {activeSpeaker.model}
                </span>
                <span className="font-telemetry-sm text-[#e2c399] text-xs shrink-0 ml-2">
                  {activeSpeaker.sensitivity} dB / 2.83V
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 font-telemetry-sm text-xs pt-1">
                <div className="bg-[#0d0e10] p-2 rounded flex flex-col">
                  <span className="text-[#998f83] text-[10px]">Z_NOMINAL</span>
                  <span className="text-[#e3e2e5] font-medium">{activeSpeaker.nominalImpedance.toFixed(1)} Ω</span>
                </div>
                <div className="bg-[#0d0e10] p-2 rounded flex flex-col">
                  <span className="text-[#998f83] text-[10px]">Z_MINIMA</span>
                  <span className="text-[#ffb4ab] font-medium">
                    {activeSpeaker.minImpedance.toFixed(1)} Ω @ {activeSpeaker.minImpedanceFreq}Hz
                  </span>
                </div>
                <div className="bg-[#0d0e10] p-2 rounded flex flex-col">
                  <span className="text-[#998f83] text-[10px]">θ FASE PEOR</span>
                  <span className="text-[#e2c399] font-medium">
                    {activeSpeaker.worstPhaseAngle}° @ {activeSpeaker.worstPhaseFreq}Hz
                  </span>
                </div>
                <div className="bg-[#0d0e10] p-2 rounded flex flex-col">
                  <span className="text-[#998f83] text-[10px]">EPDR MÍNIMO</span>
                  <span className="text-[#5ddea9] font-medium">
                    {activeSpeaker.epdrMin.toFixed(1)} Ω {activeSpeaker.epdrStatus === 'critical' ? 'Crítico' : 'Normal'}
                  </span>
                </div>
              </div>
            </div>

            {/* Coupling Link */}
            <div className="lg:col-span-4 flex flex-col gap-3 bg-[#1b1c1e] rounded p-4 border border-[#272c35]">
              <div className="flex items-center justify-between">
                <span className="font-label-caps text-[#d1c5b8] uppercase text-[10px]">
                  {lang === 'es' ? 'AMPLIFICADOR / SUMINISTRO' : 'AMPLIFIER / POWER SUPPLY'}
                </span>
                <span className="px-1.5 py-0.5 rounded bg-[#0d0e10] text-[#5ddea9] font-telemetry-sm text-[10px]">
                  VERIFICADO
                </span>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="font-headline-md text-base text-[#e3e2e5] font-semibold truncate">
                  {activeAmp.brand} {activeAmp.model}
                </span>
                <span className="font-telemetry-sm text-[#e2c399] text-xs shrink-0 ml-2">
                  {activeAmp.topology}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 font-telemetry-sm text-xs pt-1">
                <div className="bg-[#0d0e10] p-2 rounded flex flex-col">
                  <span className="text-[#998f83] text-[10px]">POTENCIA @ 8Ω</span>
                  <span className="text-[#e3e2e5] font-medium">{activeAmp.power8Ohm} W RMS</span>
                </div>
                <div className="bg-[#0d0e10] p-2 rounded flex flex-col">
                  <span className="text-[#998f83] text-[10px]">POTENCIA @ 4Ω</span>
                  <span className="text-[#5ddea9] font-medium">{activeAmp.power4Ohm} W RMS</span>
                </div>
                <div className="bg-[#0d0e10] p-2 rounded flex flex-col">
                  <span className="text-[#998f83] text-[10px]">FACTOR D.F.</span>
                  <span className="text-[#5ddea9] font-medium">&gt; {activeAmp.dampingFactor}</span>
                </div>
                <div className="bg-[#0d0e10] p-2 rounded flex flex-col">
                  <span className="text-[#998f83] text-[10px]">CAPACIDAD CORRIENTE</span>
                  <span className="text-[#e3e2e5] font-medium">{activeAmp.peakCurrent} A Pico</span>
                </div>
              </div>
            </div>

            {/* Realtime Result Summary */}
            <div className="lg:col-span-4 flex flex-col justify-between bg-[#1f2022] rounded p-4 border border-[#272c35]">
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="font-label-caps uppercase text-[#5ddea9] text-[10px]">
                    {lang === 'es' ? 'ACOPLE: TOTALMENTE CONFORME' : 'COUPLING: FULLY COMPLIANT'}
                  </span>
                  <span className="font-telemetry-sm text-[#e2c399] font-bold text-sm">
                    {verdict.score} / 100
                  </span>
                </div>
                <p className="font-body-sm text-xs text-[#d1c5b8] pt-1 leading-relaxed">
                  {verdict.summary}
                </p>
              </div>

              <div className="pt-4 flex flex-col gap-1.5">
                <div className="flex justify-between font-telemetry-sm text-[10px] text-[#998f83]">
                  <span>{lang === 'es' ? 'RESERVA DE POTENCIA' : 'POWER HEADROOM'}</span>
                  <span className="text-[#5ddea9]">
                    {verdict.headroomDb >= 0 ? `+${verdict.headroomDb} dB SOBRE UMBRAL` : `${verdict.headroomDb} dB`}
                  </span>
                </div>
                <div className="w-full h-1.5 rounded bg-[#0d0e10] overflow-hidden">
                  <div
                    className="h-full bg-[#5ddea9] transition-all duration-300"
                    style={{ width: `${Math.min(100, Math.max(15, (verdict.headroomDb + 10) * 5))}%` }}
                  />
                </div>
                <div className="pt-2 flex justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      if (onSelectChainForConfig) {
                        onSelectChainForConfig(activeSpeaker.id, activeAmp.id);
                      }
                      onNavigate('resultado');
                    }}
                    id="link-ver-telemetria"
                    className="font-telemetry-sm text-xs text-[#e2c399] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span>{lang === 'es' ? 'Ver telemetría completa' : 'View full telemetry'}</span>
                    <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
