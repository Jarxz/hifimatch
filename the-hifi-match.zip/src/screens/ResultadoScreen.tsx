import React, { useState } from 'react';
import { ScreenTab, Speaker, Amplifier, RoomEnvironment } from '../types';
import { calculateSystemCompatibility } from '../data/physicalRules';

interface ResultadoScreenProps {
  speaker: Speaker;
  amp: Amplifier;
  room: RoomEnvironment;
  onNavigate: (tab: ScreenTab) => void;
  lang: 'es' | 'en';
}

export const ResultadoScreen: React.FC<ResultadoScreenProps> = ({
  speaker,
  amp,
  room,
  onNavigate,
  lang,
}) => {
  const verdict = calculateSystemCompatibility(speaker, amp, room);
  const [activeTab, setActiveTab] = useState<'telemetry' | 'epdr' | 'acoustics'>('telemetry');

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-10 flex flex-col gap-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#272c35] pb-6">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <span className="font-label-caps text-[#e2c399] tracking-widest text-xs uppercase">
              {lang === 'es' ? 'DICTAMEN DE LABORATORIO // IEC 60268-5' : 'LABORATORY AUDIT // IEC 60268-5'}
            </span>
            <span className="text-[#4d463c]">|</span>
            <span className="font-telemetry-sm text-[11px] text-[#5ddea9]">
              CERT #0x88F-AES-{speaker.id.slice(0, 3)}-{amp.id.slice(0, 3)}
            </span>
          </div>
          <h1 className="font-headline-xl text-2xl sm:text-4xl uppercase font-bold text-[#e3e2e5]">
            {speaker.brand} {speaker.model} + {amp.brand} {amp.model}
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => onNavigate('documento')}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded bg-[#1f2022] hover:bg-[#292a2c] text-[#e2c399] border border-[#e2c399]/40 font-telemetry-sm text-xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">picture_as_pdf</span>
            <span>{lang === 'es' ? 'Ver Informe Formal' : 'Formal Report'}</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate('configurar')}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded bg-[#292a2c] text-[#d1c5b8] hover:text-[#e3e2e5] font-telemetry-sm text-xs cursor-pointer border border-[#3d4554]"
          >
            <span className="material-symbols-outlined text-[16px]">tune</span>
            <span>{lang === 'es' ? 'Reconfigurar' : 'Reconfigure'}</span>
          </button>
        </div>
      </div>

      {/* Main Score Hero Card */}
      <div className="bg-[#14171c] rounded p-6 sm:p-8 border border-[#272c35] shadow-xl flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="flex flex-col gap-3 max-w-xl">
          <div className="flex items-center gap-2">
            <span
              className={`w-3 h-3 rounded-full ${
                verdict.impedanceMatch === 'conform'
                  ? 'bg-[#5ddea9]'
                  : verdict.impedanceMatch === 'caution'
                  ? 'bg-[#e2c399]'
                  : 'bg-[#ffb4ab]'
              }`}
            />
            <span className="font-label-caps text-sm uppercase text-[#e3e2e5] font-semibold">
              {verdict.impedanceMatch === 'conform'
                ? lang === 'es'
                  ? 'ACOPLE TOTALMENTE CONFORME'
                  : 'COUPLING FULLY COMPLIANT'
                : verdict.impedanceMatch === 'caution'
                ? lang === 'es'
                  ? 'ACOPLE EN LÍMITE REACTIVO'
                  : 'COUPLING AT REACTIVE LIMIT'
                : lang === 'es'
                ? 'INSUFICIENCIA / INFRACCIÓN FÍSICA'
                : 'INSUFFICIENCY / PHYSICAL VIOLATION'}
            </span>
          </div>
          <p className="font-body-md text-sm text-[#d1c5b8] leading-relaxed">
            {verdict.summary}
          </p>
          <div className="flex flex-wrap gap-2 pt-2">
            <span className="px-2.5 py-1 rounded bg-[#0d0e10] border border-[#272c35] font-telemetry-sm text-xs text-[#5ddea9]">
              {lang === 'es' ? 'Reserva' : 'Headroom'}: {verdict.headroomDb >= 0 ? `+${verdict.headroomDb} dB` : `${verdict.headroomDb} dB`}
            </span>
            <span className="px-2.5 py-1 rounded bg-[#0d0e10] border border-[#272c35] font-telemetry-sm text-xs text-[#b6c7e5]">
              DF Efectivo: {verdict.dampingFactorEffective}
            </span>
            <span className="px-2.5 py-1 rounded bg-[#0d0e10] border border-[#272c35] font-telemetry-sm text-xs text-[#e2c399]">
              Pico Corriente: {verdict.currentMarginPercent}% Margen
            </span>
          </div>
        </div>

        {/* Big Circular Metric */}
        <div className="flex flex-col items-center justify-center p-6 bg-[#0d0e10] rounded-xl border border-[#272c35] shrink-0 min-w-[200px]">
          <span className="font-label-caps text-[10px] uppercase text-[#998f83]">
            {lang === 'es' ? 'ÍNDICE DE ACOPLE' : 'MATCH SCORE'}
          </span>
          <span className="font-headline-xl text-5xl font-bold text-[#e2c399] tracking-tight my-1">
            {verdict.score}
          </span>
          <span className="font-telemetry-sm text-[11px] text-[#5ddea9]">
            {lang === 'es' ? 'ESCALA AES-2ID / 100' : 'AES-2ID SCALE / 100'}
          </span>
        </div>
      </div>

      {/* Navigation Subtabs */}
      <div className="flex items-center gap-2 border-b border-[#272c35] pb-2 font-telemetry-sm text-xs">
        <button
          type="button"
          onClick={() => setActiveTab('telemetry')}
          className={`px-4 py-2 rounded transition-all cursor-pointer ${
            activeTab === 'telemetry'
              ? 'bg-[#1f2022] text-[#e2c399] border-b-2 border-[#e2c399]'
              : 'text-[#d1c5b8] hover:text-[#e3e2e5]'
          }`}
        >
          {lang === 'es' ? '1. Curva Z(ω) & Reactancia' : '1. Curve Z(ω) & Reactance'}
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('epdr')}
          className={`px-4 py-2 rounded transition-all cursor-pointer ${
            activeTab === 'epdr'
              ? 'bg-[#1f2022] text-[#e2c399] border-b-2 border-[#e2c399]'
              : 'text-[#d1c5b8] hover:text-[#e3e2e5]'
          }`}
        >
          {lang === 'es' ? '2. Análisis EPDR de Fincham' : '2. Fincham EPDR Analysis'}
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('acoustics')}
          className={`px-4 py-2 rounded transition-all cursor-pointer ${
            activeTab === 'acoustics'
              ? 'bg-[#1f2022] text-[#e2c399] border-b-2 border-[#e2c399]'
              : 'text-[#d1c5b8] hover:text-[#e3e2e5]'
          }`}
        >
          {lang === 'es' ? '3. Presión Acústica & Sala' : '3. Room SPL & Dispersion'}
        </button>
      </div>

      {/* Tab 1: Impedance & Phase Vector */}
      {activeTab === 'telemetry' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-8 bg-[#14171c] rounded p-6 border border-[#272c35] flex flex-col gap-4 shadow-lg">
            <div className="flex items-center justify-between">
              <span className="font-label-caps text-xs text-[#e2c399] uppercase">
                {lang === 'es' ? 'RESPUESTA DE IMPEDANCIA Y ÁNGULO DE FASE' : 'IMPEDANCE & PHASE VECTOR RESPONSE'}
              </span>
              <div className="flex items-center gap-4 font-telemetry-sm text-[11px]">
                <span className="flex items-center gap-1 text-[#e2c399]">
                  <span className="w-2 h-0.5 bg-[#e2c399]" /> |Z| Módulo (Ω)
                </span>
                <span className="flex items-center gap-1 text-[#5ddea9]">
                  <span className="w-2 h-0.5 bg-[#5ddea9]" /> θ Fase (°)
                </span>
              </div>
            </div>

            {/* Vector Graph Visualization */}
            <div className="h-64 w-full bg-[#0d0e10] rounded p-4 border border-[#272c35] relative flex flex-col justify-between">
              <svg className="w-full h-44 text-[#e2c399]" fill="none" viewBox="0 0 600 200">
                {/* Horizontal grid lines */}
                <line stroke="#272c35" strokeDasharray="2 4" x1="0" x2="600" y1="40" y2="40" />
                <line stroke="#272c35" strokeDasharray="2 4" x1="0" x2="600" y1="80" y2="80" />
                <line stroke="#272c35" strokeDasharray="2 4" x1="0" x2="600" y1="120" y2="120" />
                <line stroke="#272c35" strokeDasharray="2 4" x1="0" x2="600" y1="160" y2="160" />

                {/* Impedance Curve |Z| */}
                <path
                  d="M 10 140 C 60 160, 90 40, 120 45 C 160 55, 200 155, 260 152 C 340 150, 420 110, 500 95 C 550 85, 580 50, 595 55"
                  stroke="#e2c399"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />

                {/* Phase Curve θ */}
                <path
                  d="M 10 90 C 70 80, 100 130, 150 115 C 220 90, 260 160, 320 140 C 400 110, 500 80, 595 85"
                  stroke="#5ddea9"
                  strokeWidth="1.75"
                  strokeDasharray="4 4"
                  strokeLinecap="round"
                />

                {/* Minima Marker */}
                <circle cx="260" cy="152" r="5" fill="#ffb4ab" />
                <text x="270" y="152" fill="#ffb4ab" className="font-telemetry-sm text-[10px]">
                  Z_min: {speaker.minImpedance}Ω ({speaker.minImpedanceFreq}Hz)
                </text>

                {/* Critical Phase Marker */}
                <circle cx="320" cy="140" r="4" fill="#e2c399" />
                <text x="330" y="140" fill="#e2c399" className="font-telemetry-sm text-[10px]">
                  θ: {speaker.worstPhaseAngle}° ({speaker.worstPhaseFreq}Hz)
                </text>
              </svg>

              <div className="flex justify-between font-telemetry-sm text-[10px] text-[#998f83] pt-2 border-t border-[#272c35]">
                <span>20 Hz</span>
                <span>100 Hz</span>
                <span>500 Hz</span>
                <span>1 kHz</span>
                <span>5 kHz</span>
                <span>20 kHz</span>
              </div>
            </div>

            <p className="font-body-sm text-xs text-[#d1c5b8] leading-relaxed">
              {speaker.brand} {speaker.model} {lang === 'es' ? 'presenta un valle de impedancia en' : 'has an impedance minimum at'} {speaker.minImpedanceFreq}Hz ({speaker.minImpedance}Ω). {lang === 'es' ? 'La etapa' : 'The'} {amp.brand} {amp.model} {amp.power4Ohm >= 200 ? (lang === 'es' ? 'dispone de suficiente capacidad en corriente para estabilizar los raíles sin recorte de voltaje.' : 'has ample current reserve to stabilize voltage rails without premature clipping.') : (lang === 'es' ? 'deberá ser operada con precaución a volúmenes pico.' : 'should be operated prudently at high peak volumes.')}
            </p>
          </div>

          <div className="lg:col-span-4 flex flex-col gap-4">
            <div className="bg-[#14171c] rounded p-6 border border-[#272c35] flex flex-col gap-3 shadow-lg">
              <span className="font-label-caps text-xs text-[#b6c7e5] uppercase">
                {lang === 'es' ? 'PARÁMETROS ELÉCTRICOS CLAVE' : 'KEY ELECTRICAL PARAMETERS'}
              </span>
              <div className="flex flex-col gap-2 font-telemetry-sm text-xs">
                <div className="flex justify-between py-1.5 px-2 bg-[#0d0e10] rounded">
                  <span className="text-[#998f83]">EPDR Mínimo</span>
                  <span className="text-[#ffb4ab] font-medium">{speaker.epdrMin} Ω</span>
                </div>
                <div className="flex justify-between py-1.5 px-2 bg-[#0d0e10] rounded">
                  <span className="text-[#998f83]">DF Amplificador @ 8Ω</span>
                  <span className="text-[#5ddea9] font-medium">&gt; {amp.dampingFactor}</span>
                </div>
                <div className="flex justify-between py-1.5 px-2 bg-[#0d0e10] rounded">
                  <span className="text-[#998f83]">DF Efectivo en Bornes</span>
                  <span className="text-[#5ddea9] font-medium">{verdict.dampingFactorEffective}</span>
                </div>
                <div className="flex justify-between py-1.5 px-2 bg-[#0d0e10] rounded">
                  <span className="text-[#998f83]">Margen de Corriente</span>
                  <span className="text-[#e2c399] font-medium">+{verdict.currentMarginPercent}%</span>
                </div>
              </div>
            </div>

            <div className="bg-[#14171c] rounded p-6 border border-[#272c35] flex flex-col gap-2 shadow-lg">
              <span className="font-label-caps text-[10px] text-[#b6c7e5] uppercase">
                [ CRITERIO EDITORIAL ]
              </span>
              <p className="font-body-sm text-xs text-[#d1c5b8] leading-relaxed">
                {lang === 'es'
                  ? 'Un factor de amortiguamiento mayor a 20 garantiza que las variaciones inducidas por la fuerza contraelectromotriz sean inferiores al umbral psicoacústico de audibilidad (0.15 dB).'
                  : 'A damping factor greater than 20 ensures back-EMF variations remain below the psychoacoustic audibility threshold (0.15 dB).'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: EPDR Analysis */}
      {activeTab === 'epdr' && (
        <div className="bg-[#14171c] rounded p-6 border border-[#272c35] shadow-lg flex flex-col gap-6">
          <div className="flex flex-col gap-1">
            <span className="font-label-caps text-xs text-[#e2c399] uppercase">
              {lang === 'es' ? 'MODELADO DE ERIC FINCHAM (KEF RESEARCH, 1993)' : 'ERIC FINCHAM EPDR MODEL (KEF RESEARCH, 1993)'}
            </span>
            <h3 className="font-headline-lg text-lg uppercase font-bold text-[#e3e2e5]">
              {lang === 'es' ? 'Resistencia Equivalente de Disipación Pico' : 'Equivalent Peak Dissipation Resistance'}
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-[#0d0e10] p-4 rounded border border-[#272c35] flex flex-col gap-2">
              <span className="font-telemetry-sm text-[10px] text-[#998f83]">IMPEDANCIA NOMINAL</span>
              <span className="font-headline-xl text-3xl font-bold text-[#e3e2e5]">{speaker.nominalImpedance} Ω</span>
              <span className="font-body-sm text-xs text-[#d1c5b8]">
                {lang === 'es' ? 'Valor especificado por el fabricante en folleto comercial.' : 'Nominal figure published in marketing sheets.'}
              </span>
            </div>

            <div className="bg-[#0d0e10] p-4 rounded border border-[#272c35] flex flex-col gap-2">
              <span className="font-telemetry-sm text-[10px] text-[#998f83]">VALLE MÍNIMO MEDIDO</span>
              <span className="font-headline-xl text-3xl font-bold text-[#e2c399]">{speaker.minImpedance} Ω</span>
              <span className="font-body-sm text-xs text-[#d1c5b8]">
                {lang === 'es' ? `Caída a ${speaker.minImpedanceFreq}Hz medida con Audio Precision.` : `Dip at ${speaker.minImpedanceFreq}Hz measured with Audio Precision.`}
              </span>
            </div>

            <div className="bg-[#0d0e10] p-4 rounded border border-[#272c35] flex flex-col gap-2">
              <span className="font-telemetry-sm text-[10px] text-[#998f83]">EPDR REAL EN SILICIO</span>
              <span className="font-headline-xl text-3xl font-bold text-[#ffb4ab]">{speaker.epdrMin} Ω</span>
              <span className="font-body-sm text-xs text-[#d1c5b8]">
                {lang === 'es' ? 'Carga resistiva que el amplificador realmente disipa debido al desfase reactivo.' : 'Equivalent resistive load the transistors must thermally handle.'}
              </span>
            </div>
          </div>

          <div className="p-4 bg-[#0d0e10] rounded border border-[#272c35] font-telemetry-sm text-xs text-[#d1c5b8] flex flex-col gap-2">
            <span className="text-[#5ddea9] font-medium">
              Ecuación: EPDR(ω) = |Z(ω)| / [ cos(θ) + sin(|θ|) · √(2) ]
            </span>
            <p>
              {lang === 'es'
                ? `Para ${speaker.brand} ${speaker.model}, el ángulo de fase de ${speaker.worstPhaseAngle}° reduce la impedancia efectiva a ${speaker.epdrMin} Ω. La etapa ${amp.brand} ${amp.model} con capacidad de corriente de ${amp.peakCurrent}A soporta esta condición térmica.`
                : `For ${speaker.brand} ${speaker.model}, phase angle of ${speaker.worstPhaseAngle}° reduces effective impedance to ${speaker.epdrMin} Ω. The ${amp.brand} ${amp.model} with ${amp.peakCurrent}A peak current tolerates this thermal load.`}
            </p>
          </div>
        </div>
      )}

      {/* Tab 3: Room Acoustics & SPL */}
      {activeTab === 'acoustics' && (
        <div className="bg-[#14171c] rounded p-6 border border-[#272c35] shadow-lg flex flex-col gap-6">
          <div className="flex flex-col gap-1">
            <span className="font-label-caps text-xs text-[#e2c399] uppercase">
              {lang === 'es' ? 'PRESIÓN SONORA & GEOMETRÍA DE SALA' : 'SOUND PRESSURE & ROOM GEOMETRY'}
            </span>
            <h3 className="font-headline-lg text-lg uppercase font-bold text-[#e3e2e5]">
              {lang === 'es' ? 'Atenuación por Inverso del Cuadrado y Margen Dinámico' : 'Inverse Square Law & Dynamic Headroom'}
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-[#0d0e10] p-4 rounded border border-[#272c35] flex flex-col gap-2">
              <span className="font-telemetry-sm text-[10px] text-[#998f83]">DISTANCIA DE ESCUCHA</span>
              <span className="font-headline-xl text-3xl font-bold text-[#e3e2e5]">{room.listeningDistance} m</span>
              <span className="font-body-sm text-xs text-[#d1c5b8]">
                {lang === 'es' ? `Atenuación geométrica: -${(20 * Math.log10(room.listeningDistance)).toFixed(1)} dB` : `Geometric attenuation: -${(20 * Math.log10(room.listeningDistance)).toFixed(1)} dB`}
              </span>
            </div>

            <div className="bg-[#0d0e10] p-4 rounded border border-[#272c35] flex flex-col gap-2">
              <span className="font-telemetry-sm text-[10px] text-[#998f83]">SPL PICO DISPONIBLE</span>
              <span className="font-headline-xl text-3xl font-bold text-[#5ddea9]">{verdict.splAtListeningPoint} dB</span>
              <span className="font-body-sm text-xs text-[#d1c5b8]">
                {lang === 'es' ? 'Presión acústica máxima sin sobrecargar la etapa.' : 'Maximum sound pressure without clipping.'}
              </span>
            </div>

            <div className="bg-[#0d0e10] p-4 rounded border border-[#272c35] flex flex-col gap-2">
              <span className="font-telemetry-sm text-[10px] text-[#998f83]">HEADROOM SOBRE AES20</span>
              <span className="font-headline-xl text-3xl font-bold text-[#e2c399]">
                {verdict.headroomDb >= 0 ? `+${verdict.headroomDb}` : verdict.headroomDb} dB
              </span>
              <span className="font-body-sm text-xs text-[#d1c5b8]">
                {lang === 'es' ? 'Meta: 85 dBA + 14 dB pico = 99 dB SPL' : 'Target: 85 dBA + 14 dB musical peak = 99 dB SPL'}
              </span>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="button"
              onClick={() => onNavigate('ar-calibracion')}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded bg-[#e2c399] text-[#402d0f] font-headline-md text-xs font-semibold hover:bg-[#e0c298] cursor-pointer"
            >
              <span>{lang === 'es' ? 'Simular Ondas Estacionarias en Sala (Rayleigh)' : 'Simulate Standing Waves in Room (Rayleigh)'}</span>
              <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
