import React, { useState } from 'react';
import { ScreenTab } from '../types';
import { PHYSICAL_RULES, EDITORIAL_CRITERIA } from '../data/physicalRules';

interface GuiaScreenProps {
  onNavigate: (tab: ScreenTab) => void;
  lang: 'es' | 'en';
}

export const GuiaScreen: React.FC<GuiaScreenProps> = ({ onNavigate, lang }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: lang === 'es' ? 'Todas las Reglas' : 'All Rules' },
    { id: 'Electrodynamics', label: lang === 'es' ? 'Electrodinámica' : 'Electrodynamics' },
    { id: 'Acoustics', label: lang === 'es' ? 'Acústica de Salas' : 'Room Acoustics' },
    { id: 'Thermodynamics', label: lang === 'es' ? 'Termodinámica' : 'Thermodynamics' },
  ];

  const filteredRules =
    selectedCategory === 'all'
      ? PHYSICAL_RULES
      : PHYSICAL_RULES.filter((r) => r.category === selectedCategory);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-10 flex flex-col gap-8">
      {/* Intro Header */}
      <div className="flex flex-col gap-2 border-b border-[#272c35] pb-6">
        <div className="flex items-center gap-2">
          <span className="font-label-caps text-[#e2c399] tracking-widest text-xs uppercase">
            CORPUS TEÓRICO // DETERMINISMO FÍSICO
          </span>
          <span className="text-[#4d463c]">|</span>
          <span className="font-telemetry-sm text-[11px] text-[#5ddea9]">
            46 ECUACIONES AUDITADAS
          </span>
        </div>
        <h1 className="font-headline-xl text-2xl sm:text-4xl uppercase font-bold text-[#e3e2e5]">
          {lang === 'es' ? 'Guía de Física & Fundamentos Acústicos' : 'Physics Guide & Acoustic Fundamentals'}
        </h1>
        <p className="font-body-md text-sm text-[#d1c5b8] max-w-3xl leading-relaxed">
          {lang === 'es'
            ? 'En The Hifi Match, el comportamiento del sonido y la electricidad se modela exclusivamente mediante física refutable. Prohibidos los adjetivos pseudocientíficos: cada fenómeno es reducible a tensión, corriente, dispersión modal o presión sonora.'
            : 'In The Hifi Match, sound and electrical behaviors are modeled strictly through refutable physics. Subjective marketing buzzwords are banned: each phenomenon reduces to voltage, current, modal dispersion, or sound pressure.'}
        </p>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap items-center gap-2">
        {categories.map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3.5 py-1.5 rounded font-telemetry-sm text-xs transition-all cursor-pointer ${
              selectedCategory === cat.id
                ? 'bg-[#e2c399] text-[#402d0f] font-semibold shadow-md'
                : 'bg-[#1f2022] text-[#d1c5b8] hover:text-[#e3e2e5] border border-[#272c35]'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredRules.map((rule) => (
          <div
            key={rule.id}
            className="bg-[#14171c] rounded p-6 border border-[#272c35] shadow-lg flex flex-col justify-between gap-4"
          >
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="font-label-caps text-[10px] text-[#5ddea9] uppercase">
                  [ {rule.category.toUpperCase()} ]
                </span>
                <span className="font-telemetry-sm text-[10px] text-[#998f83]">
                  {rule.normReference}
                </span>
              </div>
              <h2 className="font-headline-md text-base font-semibold text-[#e3e2e5]">
                {rule.title}
              </h2>
              <div className="bg-[#0d0e10] p-3 rounded border border-[#272c35] my-1 font-telemetry-md text-[#e2c399] font-bold text-center tracking-wider">
                {rule.formula}
              </div>
              <p className="font-body-sm text-xs text-[#d1c5b8] leading-relaxed">
                {rule.explanation}
              </p>
            </div>

            <div className="pt-2 border-t border-[#272c35] flex flex-col gap-1">
              <span className="font-label-caps text-[9px] text-[#998f83] uppercase">
                {lang === 'es' ? 'VARIABLES DEL MODELO' : 'MODEL VARIABLES'}
              </span>
              <div className="grid grid-cols-2 gap-1 font-telemetry-sm text-[10px] text-[#b6c7e5]">
                {rule.variables.map((v, idx) => (
                  <div key={idx} className="truncate">
                    <span className="text-[#e2c399] font-medium">{v.symbol}</span>: {v.desc} ({v.unit})
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Editorial Criteria Transparency Section */}
      <div className="bg-[#1b1c1e] rounded p-6 sm:p-8 border border-[#272c35] flex flex-col gap-6 mt-4">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-[#b6c7e5]" />
            <span className="font-label-caps text-xs text-[#b6c7e5] uppercase">
              CAPA 02: CRITERIO EDITORIAL TRANSPARENTE
            </span>
          </div>
          <h2 className="font-headline-lg text-xl uppercase font-bold text-[#e3e2e5]">
            {lang === 'es'
              ? 'Por qué separamos Ley Física de Criterio Editorial'
              : 'Why Physical Law and Editorial Criteria are Segregated'}
          </h2>
          <p className="font-body-md text-xs sm:text-sm text-[#d1c5b8] max-w-3xl leading-relaxed">
            {lang === 'es'
              ? 'En la industria audiófila, es habitual que opiniones subjetivas o recomendaciones comerciales se disfracen de "física". En The Hifi Match, todo juicio de valor lleva una etiqueta indeleble para que el usuario siempre sepa qué es una ley invariable del universo y qué es una recomendación de diseño.'
              : 'In the audio industry, personal taste is frequently disguised as "physics". In The Hifi Match, every subjective guideline is indelibly badged so the user knows what is universal physics versus an engineering judgment.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {EDITORIAL_CRITERIA.map((crit) => (
            <div
              key={crit.id}
              className="bg-[#0d0e10] p-4 rounded border border-[#394a62]/50 flex flex-col gap-2"
            >
              <div className="flex items-center justify-between">
                <span className="font-label-caps text-[9px] text-[#b6c7e5] px-2 py-0.5 rounded bg-[#1f2022] border border-[#394a62]">
                  [{crit.badge}]
                </span>
                <span className="font-telemetry-sm text-[11px] text-[#e2c399]">
                  {crit.standardValue}
                </span>
              </div>
              <h3 className="font-headline-md text-sm font-semibold text-[#e3e2e5]">
                {crit.title}
              </h3>
              <p className="font-body-sm text-xs text-[#d1c5b8] leading-relaxed">
                {crit.rationale}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
