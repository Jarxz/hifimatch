import React from 'react';
import { ScreenTab, Speaker, Amplifier, RoomEnvironment } from '../types';
import { SPEAKERS_DATABASE, AMPLIFIERS_DATABASE } from '../data/equipment';

interface ConfigurarScreenProps {
  selectedSpeaker: Speaker;
  selectedAmp: Amplifier;
  room: RoomEnvironment;
  onSelectSpeaker: (speaker: Speaker) => void;
  onSelectAmp: (amp: Amplifier) => void;
  onUpdateRoom: (room: Partial<RoomEnvironment>) => void;
  onNavigate: (tab: ScreenTab) => void;
  lang: 'es' | 'en';
}

export const ConfigurarScreen: React.FC<ConfigurarScreenProps> = ({
  selectedSpeaker,
  selectedAmp,
  room,
  onSelectSpeaker,
  onSelectAmp,
  onUpdateRoom,
  onNavigate,
  lang,
}) => {
  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-10 flex flex-col gap-8">
      {/* Header / Intro */}
      <div className="flex flex-col gap-2 border-b border-[#272c35] pb-6">
        <div className="flex items-center gap-2">
          <span className="font-label-caps text-[#e2c399] tracking-widest text-xs uppercase">
            RACK DE CONFIGURACIÓN // IEC 60268-5
          </span>
          <span className="text-[#4d463c]">|</span>
          <span className="font-telemetry-sm text-[11px] text-[#5ddea9]">
            {lang === 'es' ? '182 EQUIPOS INDEXADOS' : '182 INDEXED UNITS'}
          </span>
        </div>
        <h1 className="font-headline-xl text-2xl sm:text-4xl uppercase font-bold text-[#e3e2e5]">
          {lang === 'es'
            ? 'Configuración del Banco Electroacústico'
            : 'Electroacoustic Bench Configuration'}
        </h1>
        <p className="font-body-md text-sm text-[#d1c5b8] max-w-2xl">
          {lang === 'es'
            ? 'Selecciona los componentes de la cadena y define las características físicas de tu sala. El motor computará el acoplamiento de impedancia y la disipación térmica en tiempo real.'
            : 'Select the components in your chain and input your room acoustic dimensions. The engine will compute impedance coupling and thermal headroom in real time.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Speaker & Amp Selectors */}
        <div className="lg:col-span-7 flex flex-col gap-8">
          {/* Section 1: Transducer Selection */}
          <div className="bg-[#14171c] rounded p-6 border border-[#272c35] shadow-lg flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-[#272c35] pb-3">
              <div className="flex items-center gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#e2c399]" />
                <h2 className="font-headline-md text-base uppercase font-semibold text-[#e3e2e5]">
                  {lang === 'es' ? '1. Transductor / Altavoz' : '1. Loudspeaker / Transducer'}
                </h2>
              </div>
              <span className="font-telemetry-sm text-[11px] text-[#998f83]">
                {SPEAKERS_DATABASE.length} {lang === 'es' ? 'Modelos de Referencia' : 'Reference Models'}
              </span>
            </div>

            {/* Speaker Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {SPEAKERS_DATABASE.map((spk) => {
                const isSelected = spk.id === selectedSpeaker.id;
                return (
                  <button
                    key={spk.id}
                    type="button"
                    onClick={() => onSelectSpeaker(spk)}
                    className={`text-left p-3.5 rounded border transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-[#1f2022] border-[#e2c399] shadow-md'
                        : 'bg-[#0d0e10] border-[#272c35] hover:border-[#4d463c]'
                    }`}
                  >
                    <div className="flex flex-col gap-0.5">
                      <div className="flex items-center justify-between">
                        <span className="font-label-caps text-[10px] text-[#e2c399] uppercase">
                          {spk.brand}
                        </span>
                        <span
                          className={`font-telemetry-sm text-[10px] px-1.5 py-0.2 rounded ${
                            spk.epdrStatus === 'critical'
                              ? 'bg-[#93000a]/40 text-[#ffb4ab]'
                              : 'bg-[#004a33]/40 text-[#5ddea9]'
                          }`}
                        >
                          EPDR {spk.epdrMin.toFixed(1)}Ω
                        </span>
                      </div>
                      <span className="font-headline-md text-sm font-semibold text-[#e3e2e5]">
                        {spk.model}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-1 font-telemetry-sm text-[10px] pt-3 text-[#998f83]">
                      <div>
                        Sens: <span className="text-[#e3e2e5]">{spk.sensitivity} dB</span>
                      </div>
                      <div>
                        Z_min: <span className="text-[#ffb4ab]">{spk.minImpedance}Ω</span>
                      </div>
                      <div>
                        Nom: <span className="text-[#e3e2e5]">{spk.nominalImpedance}Ω</span>
                      </div>
                      <div>
                        Fase: <span className="text-[#e2c399]">{spk.worstPhaseAngle}°</span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 2: Amplifier Selection */}
          <div className="bg-[#14171c] rounded p-6 border border-[#272c35] shadow-lg flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-[#272c35] pb-3">
              <div className="flex items-center gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#5ddea9]" />
                <h2 className="font-headline-md text-base uppercase font-semibold text-[#e3e2e5]">
                  {lang === 'es' ? '2. Etapa de Potencia / Amplificador' : '2. Power Stage / Amplifier'}
                </h2>
              </div>
              <span className="font-telemetry-sm text-[11px] text-[#998f83]">
                {AMPLIFIERS_DATABASE.length} {lang === 'es' ? 'Etapas Medidas' : 'Tested Stages'}
              </span>
            </div>

            {/* Amplifier Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {AMPLIFIERS_DATABASE.map((amp) => {
                const isSelected = amp.id === selectedAmp.id;
                return (
                  <button
                    key={amp.id}
                    type="button"
                    onClick={() => onSelectAmp(amp)}
                    className={`text-left p-3.5 rounded border transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-[#1f2022] border-[#5ddea9] shadow-md'
                        : 'bg-[#0d0e10] border-[#272c35] hover:border-[#4d463c]'
                    }`}
                  >
                    <div className="flex flex-col gap-0.5">
                      <div className="flex items-center justify-between">
                        <span className="font-label-caps text-[10px] text-[#5ddea9] uppercase">
                          {amp.brand}
                        </span>
                        <span className="font-telemetry-sm text-[10px] text-[#b6c7e5]">
                          {amp.topology}
                        </span>
                      </div>
                      <span className="font-headline-md text-sm font-semibold text-[#e3e2e5]">
                        {amp.model}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-1 font-telemetry-sm text-[10px] pt-3 text-[#998f83]">
                      <div>
                        8Ω: <span className="text-[#e3e2e5]">{amp.power8Ohm}W</span>
                      </div>
                      <div>
                        4Ω: <span className="text-[#5ddea9]">{amp.power4Ohm}W</span>
                      </div>
                      <div>
                        D.F.: <span className="text-[#e3e2e5]">&gt;{amp.dampingFactor}</span>
                      </div>
                      <div>
                        Corriente: <span className="text-[#e2c399]">{amp.peakCurrent}A</span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Room Geometry & Parameters */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          <div className="bg-[#14171c] rounded p-6 border border-[#272c35] shadow-lg flex flex-col gap-5">
            <div className="flex items-center justify-between border-b border-[#272c35] pb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#b6c7e5]" />
                <h2 className="font-headline-md text-base uppercase font-semibold text-[#e3e2e5]">
                  {lang === 'es' ? '3. Parámetros del Recinto & Cable' : '3. Room Geometry & Cable'}
                </h2>
              </div>
              <span className="font-label-caps text-[10px] text-[#b6c7e5] uppercase">
                [ {lang === 'es' ? 'CRITERIO FÍSICO' : 'PHYSICAL PARAMETERS'} ]
              </span>
            </div>

            {/* Dimension Sliders */}
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between font-telemetry-sm text-xs">
                  <span className="text-[#d1c5b8]">{lang === 'es' ? 'Largo de Sala (L)' : 'Room Length (L)'}</span>
                  <span className="text-[#e2c399] font-medium">{room.length.toFixed(1)} m</span>
                </div>
                <input
                  type="range"
                  min="3.0"
                  max="12.0"
                  step="0.1"
                  value={room.length}
                  onChange={(e) => onUpdateRoom({ length: parseFloat(e.target.value) })}
                  className="w-full accent-[#e2c399] cursor-pointer"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between font-telemetry-sm text-xs">
                  <span className="text-[#d1c5b8]">{lang === 'es' ? 'Ancho de Sala (W)' : 'Room Width (W)'}</span>
                  <span className="text-[#e2c399] font-medium">{room.width.toFixed(1)} m</span>
                </div>
                <input
                  type="range"
                  min="2.5"
                  max="8.0"
                  step="0.1"
                  value={room.width}
                  onChange={(e) => onUpdateRoom({ width: parseFloat(e.target.value) })}
                  className="w-full accent-[#e2c399] cursor-pointer"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between font-telemetry-sm text-xs">
                  <span className="text-[#d1c5b8]">{lang === 'es' ? 'Altura de Techo (H)' : 'Ceiling Height (H)'}</span>
                  <span className="text-[#e2c399] font-medium">{room.height.toFixed(1)} m</span>
                </div>
                <input
                  type="range"
                  min="2.2"
                  max="4.5"
                  step="0.1"
                  value={room.height}
                  onChange={(e) => onUpdateRoom({ height: parseFloat(e.target.value) })}
                  className="w-full accent-[#e2c399] cursor-pointer"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between font-telemetry-sm text-xs">
                  <span className="text-[#d1c5b8]">
                    {lang === 'es' ? 'Distancia Punto de Escucha (d)' : 'Listening Distance (d)'}
                  </span>
                  <span className="text-[#5ddea9] font-medium">{room.listeningDistance.toFixed(1)} m</span>
                </div>
                <input
                  type="range"
                  min="1.5"
                  max="6.0"
                  step="0.1"
                  value={room.listeningDistance}
                  onChange={(e) => onUpdateRoom({ listeningDistance: parseFloat(e.target.value) })}
                  className="w-full accent-[#5ddea9] cursor-pointer"
                />
              </div>

              {/* Cable settings */}
              <div className="pt-2 border-t border-[#272c35] flex flex-col gap-3">
                <span className="font-label-caps text-[10px] text-[#998f83] uppercase">
                  {lang === 'es' ? 'CABLEADO Y PÉRDIDAS ÓHMICAS' : 'CABLING & OHMIC RESISTANCE'}
                </span>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1">
                    <span className="font-telemetry-sm text-[11px] text-[#d1c5b8]">
                      {lang === 'es' ? 'Longitud Cable' : 'Cable Length'}
                    </span>
                    <select
                      value={room.cableLength}
                      onChange={(e) => onUpdateRoom({ cableLength: parseFloat(e.target.value) })}
                      className="bg-[#0d0e10] border border-[#272c35] text-[#e3e2e5] rounded p-2 text-xs font-telemetry-sm"
                    >
                      <option value={2.0}>2.0 m</option>
                      <option value={3.0}>3.0 m (Estándar)</option>
                      <option value={5.0}>5.0 m</option>
                      <option value={8.0}>8.0 m</option>
                    </select>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span className="font-telemetry-sm text-[11px] text-[#d1c5b8]">
                      {lang === 'es' ? 'Calibre Cobre' : 'Gauge AWG'}
                    </span>
                    <select
                      value={room.cableGaugeAWG}
                      onChange={(e) => onUpdateRoom({ cableGaugeAWG: parseInt(e.target.value) })}
                      className="bg-[#0d0e10] border border-[#272c35] text-[#e3e2e5] rounded p-2 text-xs font-telemetry-sm"
                    >
                      <option value={12}>AWG 12 (3.3 mm²)</option>
                      <option value={14}>AWG 14 (2.1 mm²)</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Run Calculation CTA */}
            <div className="pt-4 border-t border-[#272c35] flex flex-col gap-3">
              <button
                type="button"
                onClick={() => onNavigate('resultado')}
                id="btn-run-audit"
                className="w-full py-3.5 px-4 rounded bg-[#e2c399] hover:bg-[#e0c298] text-[#402d0f] font-headline-md text-sm font-semibold flex items-center justify-center gap-2 shadow-lg transition-transform active:translate-y-0.5 cursor-pointer"
              >
                <span>{lang === 'es' ? 'Calcular Acople Electroacústico' : 'Run Electroacoustic Audit'}</span>
                <span className="material-symbols-outlined text-[18px]">play_arrow</span>
              </button>
              <span className="text-center font-telemetry-sm text-[10px] text-[#998f83]">
                {lang === 'es'
                  ? 'Cómputo instantáneo local • Sin dependencias externas'
                  : 'Instant local computation • Zero remote server latency'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
