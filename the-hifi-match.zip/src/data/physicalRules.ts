import { PhysicalRule, EditorialCriterion, Speaker, Amplifier, RoomEnvironment, MatchVerdict } from '../types';

export const PHYSICAL_RULES: PhysicalRule[] = [
  {
    id: 'ohm-complex',
    category: 'Electrodynamics',
    title: 'Ley de Ohm Compleja & Factor Reactivo',
    formula: 'V(t) = I(t) · |Z(ω)| ∠ θ(ω)',
    variables: [
      { symbol: 'V(t)', desc: 'Tensión instantánea en bornes', unit: 'Voltios (V)' },
      { symbol: 'I(t)', desc: 'Corriente suministrada por la etapa', unit: 'Amperios (A)' },
      { symbol: '|Z(ω)|', desc: 'Módulo de impedancia dependiente de ω', unit: 'Ohmios (Ω)' },
      { symbol: 'θ(ω)', desc: 'Ángulo de desfase tensión-corriente', unit: 'Grados (°)' },
    ],
    explanation:
      'Cuando un transductor electromagnético presenta reactancia inductiva o capacitiva (θ ≠ 0), la corriente y la tensión no alcanzan el pico simultáneamente. Esto impone una disipación térmica multiplicada sobre los transistores de la etapa de salida.',
    normReference: 'IEC 60268-5 / AES-2ID',
  },
  {
    id: 'epdr-fincham',
    category: 'Electrodynamics',
    title: 'Resistencia de Disipación Pico Equivalente (EPDR)',
    formula: 'EPDR(ω) = |Z(ω)| / [ cos(θ) + sin(|θ|) · √(2) ]',
    variables: [
      { symbol: 'EPDR', desc: 'Carga resistiva pura equivalente que causa idéntica disipación en silicio', unit: 'Ohmios (Ω)' },
      { symbol: '|Z|', desc: 'Módulo de impedancia medido', unit: 'Ohmios (Ω)' },
      { symbol: 'θ', desc: 'Fase de la impedancia', unit: 'Radianes / Grados' },
    ],
    explanation:
      'Formulado por Eric Fincham en KEF: un altavoz de 4 Ω nominales con un valle de 3.2 Ω a -45° de fase somete al amplificador al mismo estrés térmico que una resistencia pura de 1.6 Ω a 1.8 Ω.',
    normReference: 'Audio Engineering Society Convention Paper #1967',
  },
  {
    id: 'rayleigh-modes',
    category: 'Acoustics',
    title: 'Frecuencias de Resonancia Modal de Rayleigh',
    formula: 'f(p,q,r) = (c / 2) · √((p/L)² + (q/W)² + (r/H)²)',
    variables: [
      { symbol: 'c', desc: 'Velocidad del sonido a 20°C (343.2 m/s)', unit: 'm/s' },
      { symbol: 'L, W, H', desc: 'Largo, ancho y altura del recinto', unit: 'Metros (m)' },
      { symbol: 'p, q, r', desc: 'Enteros de modo axial, tangencial u oblicuo', unit: 'Adimensional' },
    ],
    explanation:
      'Ondas estacionarias de baja frecuencia que causan picos de hasta +18 dB y valles destructivos de cancelación (-25 dB) en la posición de escucha por debajo de la frecuencia de Schroeder.',
    normReference: 'Lord Rayleigh / Theory of Sound (ISO 3382)',
  },
  {
    id: 'inverse-square-spl',
    category: 'Acoustics',
    title: 'Atenuación por Inverso del Cuadrado & Campo Reverberante',
    formula: 'SPL(d) = S + 10·log₁₀(P) - 20·log₁₀(d) + G_recinto',
    variables: [
      { symbol: 'SPL', desc: 'Nivel de presión sonora en punto de escucha', unit: 'dB SPL' },
      { symbol: 'S', desc: 'Sensibilidad a 1 metro con 2.83V RMS', unit: 'dB SPL' },
      { symbol: 'P', desc: 'Potencia eléctrica suministrada', unit: 'Vatios (W)' },
      { symbol: 'd', desc: 'Distancia oído-transductor', unit: 'Metros (m)' },
      { symbol: 'G_recinto', desc: 'Refuerzo de sala (campo semi-reverberante)', unit: 'dB' },
    ],
    explanation:
      'En espacio libre la presión decae 6 dB por cada duplicación de distancia. En salas domésticas típicas, las reflexiones limitan la caída a aproximadamente 3 a 4 dB por duplicación.',
    normReference: 'ISO 226 / AES Recommended Practice',
  },
  {
    id: 'damping-factor-cable',
    category: 'Electrodynamics',
    title: 'Factor de Amortiguamiento Efectivo en Terminales',
    formula: 'DF_efectivo = Z_altavoz / ( (8 / DF_amp) + 2·R_cable + R_contacto )',
    variables: [
      { symbol: 'DF_efectivo', desc: 'Capacidad de controlar la fuerza contraelectromotriz', unit: 'Ratio adimensional' },
      { symbol: 'R_cable', desc: 'Resistencia óhmica total del conductor', unit: 'Ohmios (Ω)' },
      { symbol: 'DF_amp', desc: 'Factor de amortiguamiento nominal del amplificador @ 8Ω', unit: 'Adimensional' },
    ],
    explanation:
      'Un factor de amortiguamiento del amplificador de 4000 se reduce a ~40 si el cable de altavoz tiene 0.1 Ω de resistencia de ida y vuelta. El cable es el cuello de botella físico.',
    normReference: 'AES Journal Vol. 37 #11',
  },
  {
    id: 'thermal-compression',
    category: 'Thermodynamics',
    title: 'Compresión Térmica de Bobina Móvil',
    formula: 'ΔR_bobina = R₀ · (1 + α · ΔT)',
    variables: [
      { symbol: 'ΔR', desc: 'Incremento de resistencia por calentamiento', unit: 'Ohmios (Ω)' },
      { symbol: 'α', desc: 'Coeficiente de temperatura del cobre (0.00393 / °C)', unit: '1/°C' },
      { symbol: 'ΔT', desc: 'Aumento de temperatura en la bobina móvil', unit: '°C' },
    ],
    explanation:
      'A potencias elevadas continuas, la bobina de cobre puede alcanzar 150°C, duplicando su resistencia eléctrica y comprimiendo la respuesta dinámica entre 2 dB y 5 dB.',
    normReference: 'AES60-2010',
  },
];

export const EDITORIAL_CRITERIA: EditorialCriterion[] = [
  {
    id: 'spl-target-85',
    title: 'Umbral SPL 85 dBA + Headroom 14 dB',
    badge: 'CRITERIO EDITORIAL — NO FÍSICA',
    standardValue: '85 dBA continuo / 99 dB SPL pico',
    rationale:
      'Adoptamos el estándar AES20 de 85 dBA continuo con 14 dB de margen transitorio para dinámica orquestal como audición de referencia sin inducir fatiga ni pérdida coclear temporal (TTS).',
    userConfigurable: true,
  },
  {
    id: 'df-audibility-20',
    title: 'Límite de Audibilidad del Factor de Amortiguamiento',
    badge: 'CRITERIO EDITORIAL — NO FÍSICA',
    standardValue: 'DF_efectivo ≥ 20 en bornes',
    rationale:
      'En pruebas ciegas ABX con transductores de baja impedancia, factores de amortiguamiento por encima de 20 producen variaciones en respuesta de frecuencia inferiores a 0.15 dB, inaudibles según curvas Fletcher-Munson.',
    userConfigurable: true,
  },
  {
    id: 'budget-ratio',
    title: 'Prioridad de Inversión Fonoacústica',
    badge: 'CRITERIO EDITORIAL — NO FÍSICA',
    standardValue: '85% Sala & Transductor / 15% Electrónica',
    rationale:
      'La acústica de la sala y la dispersión angular del altavoz representan la inmensa mayoría de las aberraciones tímbricas audibles. La electrónica con THD < 0.1% tiene un impacto secundario.',
    userConfigurable: false,
  },
  {
    id: 'thermal-safety-margin',
    title: 'Margen de Potencia Térmica Preventivo',
    badge: 'CRITERIO EDITORIAL — NO FÍSICA',
    standardValue: '+3.0 dB de reserva RMS',
    rationale:
      'Recomendamos un margen de al menos 3 dB sobre el pico SPL requerido para garantizar que la etapa funcione en su región más lineal, evitando el hard-clipping asimétrico.',
    userConfigurable: true,
  },
];

export function calculateSystemCompatibility(
  speaker: Speaker,
  amp: Amplifier,
  room: RoomEnvironment
): MatchVerdict {
  // 1. Cable resistance calculation (Copper, roundtrip 2 conductors)
  // AWG 12 ~ 0.00521 ohm/m; AWG 14 ~ 0.00828 ohm/m
  const ohmsPerMeter = room.cableGaugeAWG === 12 ? 0.00521 : 0.00828;
  const cableResistance = 2 * room.cableLength * ohmsPerMeter;
  const ampOutResistance = 8.0 / Math.max(amp.dampingFactor, 1);
  const effectiveDF = speaker.nominalImpedance / (ampOutResistance + cableResistance + 0.02);

  // 2. Power delivery to speaker min impedance
  const powerAtMinZ =
    speaker.minImpedance <= 4
      ? amp.power4Ohm * (4 / speaker.minImpedance) * 0.95
      : amp.power8Ohm * (8 / speaker.minImpedance);

  // 3. Acoustic SPL at listening distance
  // Room reverberant gain: Reflective = 5dB, Typical = 3.5dB, Treated = 1.5dB
  const roomGain =
    room.treatmentType === 'Reflective' ? 5.0 : room.treatmentType === 'Typical Living Room' ? 3.5 : 1.5;
  const distanceAttenuation = 20 * Math.log10(Math.max(room.listeningDistance, 0.5));
  // Peak SPL with full RMS power from 2 channels (+3 dB for stereo summation)
  const splPeak =
    speaker.sensitivity +
    10 * Math.log10(Math.max(powerAtMinZ, 1)) -
    distanceAttenuation +
    roomGain +
    3;

  // Target peak SPL is 85 + 14 dB headroom = 99 dB SPL
  const targetSPL = 99.0;
  const headroomDb = splPeak - targetSPL;

  // Peak current demand: I_peak = sqrt(2 * P / EPDR)
  const currentDemand = Math.sqrt((2 * powerAtMinZ) / Math.max(speaker.epdrMin, 0.5));
  const currentMarginPercent = Math.round(((amp.peakCurrent - currentDemand) / amp.peakCurrent) * 100);

  // Determine impedance conformity
  let impedanceMatch: 'conform' | 'caution' | 'critical' = 'conform';
  let impedanceNotes = '';

  if (speaker.epdrMin < 2.0 && amp.peakCurrent < 35) {
    impedanceMatch = 'critical';
    impedanceNotes = `El EPDR mínimo de ${speaker.epdrMin.toFixed(1)} Ω impone un pico de corriente que excede el margen térmico continuo de la etapa.`;
  } else if (speaker.epdrMin < 2.5 || speaker.worstPhaseAngle < -50) {
    if (amp.peakCurrent >= 45) {
      impedanceMatch = 'conform';
      impedanceNotes = `La etapa disipa con soltura la demanda en el valle EPDR de ${speaker.epdrMin.toFixed(1)} Ω (${speaker.worstPhaseAngle}°).`;
    } else {
      impedanceMatch = 'caution';
      impedanceNotes = `Fase reactiva severa (${speaker.worstPhaseAngle}°). Requiere ventilación adecuada en la etapa de potencia.`;
    }
  } else {
    impedanceMatch = 'conform';
    impedanceNotes = 'Carga electroacústica benigna; la etapa opera dentro de su región de distorsión transitoria mínima.';
  }

  // Score calculation: based on Headroom, Damping Factor, Current Margin
  let score = 70;
  if (headroomDb >= 3.0) score += 15;
  else if (headroomDb >= 0) score += 8;
  else score -= 25;

  if (effectiveDF >= 20) score += 10;
  else score -= 10;

  if (impedanceMatch === 'conform') score += 5;
  else if (impedanceMatch === 'critical') score -= 30;

  score = Math.max(10, Math.min(99.4, score));

  return {
    score: Number(score.toFixed(1)),
    impedanceMatch,
    impedanceNotes,
    headroomDb: Number(headroomDb.toFixed(1)),
    splAtListeningPoint: Number(splPeak.toFixed(1)),
    dampingFactorEffective: Number(effectiveDF.toFixed(1)),
    currentMarginPercent,
    summary:
      headroomDb >= 3.0 && impedanceMatch === 'conform'
        ? `Acople totalmente conforme bajo especificaciones IEC. La etapa suministra holgadamente la corriente demandada con un margen dinámico acústico de ${splPeak.toFixed(1)} dB SPL a ${room.listeningDistance}m.`
        : headroomDb < 0
        ? `Reserva de potencia insuficiente. Se anticipa clipping prematuro antes de alcanzar el estándar de audición de referencia (99 dB SPL pico).`
        : `Acople dentro de tolerancias operativas admisibles con monitoreo de temperatura en la etapa de salida.`,
  };
}
