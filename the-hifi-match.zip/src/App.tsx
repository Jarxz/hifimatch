import { useState } from 'react';
import { ScreenTab, Speaker, Amplifier, RoomEnvironment } from './types';
import { SPEAKERS_DATABASE, AMPLIFIERS_DATABASE } from './data/equipment';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { BootSplash } from './components/BootSplash';
import { PortadaScreen } from './screens/PortadaScreen';
import { ConfigurarScreen } from './screens/ConfigurarScreen';
import { ResultadoScreen } from './screens/ResultadoScreen';
import { GuiaScreen } from './screens/GuiaScreen';
import { DocumentoScreen } from './screens/DocumentoScreen';
import { ARCalibracionScreen } from './screens/ARCalibracionScreen';

export default function App() {
  const [currentTab, setCurrentTab] = useState<ScreenTab>('portada');
  const [showBootSplash, setShowBootSplash] = useState<boolean>(true);
  const [lang, setLang] = useState<'es' | 'en'>('es');

  // Active laboratory setup state
  const [selectedSpeaker, setSelectedSpeaker] = useState<Speaker>(SPEAKERS_DATABASE[0]);
  const [selectedAmp, setSelectedAmp] = useState<Amplifier>(AMPLIFIERS_DATABASE[0]);
  const [room, setRoom] = useState<RoomEnvironment>({
    length: 5.8,
    width: 4.2,
    height: 2.8,
    listeningDistance: 3.2,
    treatmentType: 'Typical Living Room',
    cableLength: 3.0,
    cableGaugeAWG: 12,
  });

  const handleSelectChainForConfig = (speakerId: string, ampId: string) => {
    const spk = SPEAKERS_DATABASE.find((s) => s.id === speakerId);
    const amp = AMPLIFIERS_DATABASE.find((a) => a.id === ampId);
    if (spk) setSelectedSpeaker(spk);
    if (amp) setSelectedAmp(amp);
  };

  const handleUpdateRoom = (updated: Partial<RoomEnvironment>) => {
    setRoom((prev) => ({ ...prev, ...updated }));
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#121315] text-[#e3e2e5]">
      {/* Interactive Acoustic Matrix Boot Sequence */}
      <BootSplash
        isOpen={showBootSplash}
        onDismiss={() => setShowBootSplash(false)}
      />

      {/* Persistent Laboratory Instrument Header */}
      <Header
        currentTab={currentTab}
        onNavigate={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onReplayBoot={() => setShowBootSplash(true)}
        lang={lang}
        onToggleLang={(l) => setLang(l)}
      />

      {/* Main Screen Content Deck */}
      <main className="flex-1 w-full pt-20">
        {currentTab === 'portada' && (
          <PortadaScreen
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            lang={lang}
            onSelectChainForConfig={handleSelectChainForConfig}
          />
        )}

        {currentTab === 'configurar' && (
          <ConfigurarScreen
            selectedSpeaker={selectedSpeaker}
            selectedAmp={selectedAmp}
            room={room}
            onSelectSpeaker={setSelectedSpeaker}
            onSelectAmp={setSelectedAmp}
            onUpdateRoom={handleUpdateRoom}
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            lang={lang}
          />
        )}

        {currentTab === 'resultado' && (
          <ResultadoScreen
            speaker={selectedSpeaker}
            amp={selectedAmp}
            room={room}
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            lang={lang}
          />
        )}

        {currentTab === 'guia' && (
          <GuiaScreen
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            lang={lang}
          />
        )}

        {currentTab === 'documento' && (
          <DocumentoScreen
            speaker={selectedSpeaker}
            amp={selectedAmp}
            room={room}
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            lang={lang}
          />
        )}

        {currentTab === 'ar-calibracion' && (
          <ARCalibracionScreen
            room={room}
            onUpdateRoom={handleUpdateRoom}
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            lang={lang}
          />
        )}
      </main>

      {/* Lab Instrument Platform Footer */}
      <Footer lang={lang} />
    </div>
  );
}
