export type ScreenTab =
  | 'portada'
  | 'configurar'
  | 'resultado'
  | 'guia'
  | 'documento'
  | 'ar-calibracion';

export interface Speaker {
  id: string;
  brand: string;
  model: string;
  type: 'Standmount' | 'Floorstander' | 'Monitor';
  sensitivity: number; // dB @ 2.83V / 1m
  nominalImpedance: number; // Ohms
  minImpedance: number; // Ohms
  minImpedanceFreq: number; // Hz
  worstPhaseAngle: number; // degrees
  worstPhaseFreq: number; // Hz
  epdrMin: number; // Equivalent Peak Dissipation Resistance (Ohms)
  epdrStatus: 'critical' | 'moderate' | 'easy';
  recommendedPowerMin: number; // Watts
  recommendedPowerMax: number; // Watts
  cabinetType: 'Bass Reflex' | 'Sealed' | 'Passive Radiator';
  frequencyResponse: string;
}

export interface Amplifier {
  id: string;
  brand: string;
  model: string;
  topology: 'Class AB' | 'Class A' | 'Class D' | 'Tube Pentode';
  power8Ohm: number; // Watts RMS
  power4Ohm: number; // Watts RMS
  power2Ohm?: number; // Watts RMS
  dampingFactor: number; // @ 1kHz, 8 Ohms
  peakCurrent: number; // Amperes peak
  thdAtNominal: number; // %
  slewRate: number; // V/µs
  inputSensitivity: number; // V
}

export interface RoomEnvironment {
  length: number; // meters
  width: number; // meters
  height: number; // meters
  listeningDistance: number; // meters
  treatmentType: 'Reflective' | 'Typical Living Room' | 'Treated Studio';
  cableLength: number; // meters
  cableGaugeAWG: number; // AWG e.g. 12 or 14
}

export interface MatchVerdict {
  score: number; // 0 - 100
  impedanceMatch: 'conform' | 'caution' | 'critical';
  impedanceNotes: string;
  headroomDb: number;
  splAtListeningPoint: number;
  dampingFactorEffective: number;
  currentMarginPercent: number;
  summary: string;
}

export interface PhysicalRule {
  id: string;
  category: 'Electrodynamics' | 'Acoustics' | 'Psychoacoustics' | 'Thermodynamics';
  title: string;
  formula: string;
  variables: { symbol: string; desc: string; unit: string }[];
  explanation: string;
  normReference: string;
}

export interface EditorialCriterion {
  id: string;
  title: string;
  badge: string;
  standardValue: string;
  rationale: string;
  userConfigurable: boolean;
}
