import React, { useState } from 'react';

interface FooterProps {
  lang: 'es' | 'en';
}

export const Footer: React.FC<FooterProps> = ({ lang }) => {
  const [modalType, setModalType] = useState<'about' | 'contact' | 'privacy' | null>(null);

  return (
    <>
      <footer className="w-full bg-[#0d0e10] border-t border-[#272c35] mt-16">
        <div className="w-full px-6 py-12 max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          <div className="flex flex-col gap-2">
            <div className="flex items-baseline gap-2">
              <span className="font-headline-md text-base text-[#e2c399] font-semibold uppercase">
                The Hifi Match
              </span>
              <span className="font-telemetry-sm text-[11px] text-[#998f83]">v2.4.0-PRO</span>
            </div>
            <p className="font-body-sm text-xs text-[#d1c5b8] max-w-md leading-relaxed">
              {lang === 'es'
                ? 'Basado en física, specs medidos — tú escuchas y decides. Diagnósticos de acoplamiento acústico, impedancia reactiva y cálculo de presión sonora.'
                : 'Built on empirical physics and measured specs — you listen and decide. Acoustic coupling diagnoses, reactive impedance and sound pressure level calculations.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6">
            <button
              type="button"
              onClick={() => setModalType('about')}
              className="font-label-caps text-[11px] uppercase text-[#d1c5b8] hover:text-[#e2c399] transition-colors cursor-pointer"
            >
              {lang === 'es' ? 'Acerca de' : 'About'}
            </button>
            <button
              type="button"
              onClick={() => setModalType('contact')}
              className="font-label-caps text-[11px] uppercase text-[#d1c5b8] hover:text-[#e2c399] transition-colors cursor-pointer"
            >
              {lang === 'es' ? 'Contacto' : 'Contact'}
            </button>
            <button
              type="button"
              onClick={() => setModalType('privacy')}
              className="font-label-caps text-[11px] uppercase text-[#d1c5b8] hover:text-[#e2c399] transition-colors cursor-pointer"
            >
              {lang === 'es' ? 'Privacidad' : 'Privacy'}
            </button>
          </div>
        </div>

        <div className="w-full px-6 py-4 bg-[#070809] border-t border-[#1b1c1e]">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 font-telemetry-sm text-[11px] text-[#998f83]">
            <div className="flex items-center gap-4">
              <span>LAB INSTRUMENT PLATFORM</span>
              <span>© {new Date().getFullYear()} THEHIFIMATCH.COM</span>
            </div>
            <span>CALIBRATED SPECS: IEC 60268-5 / AES-2ID</span>
          </div>
        </div>
      </footer>

      {/* Info Modal */}
      {modalType && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="bg-[#14171c] border border-[#272c35] rounded max-w-lg w-full p-6 flex flex-col gap-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#272c35] pb-3">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#e2c399]" />
                <span className="font-headline-md uppercase font-bold text-[#e3e2e5]">
                  {modalType === 'about'
                    ? lang === 'es'
                      ? 'Acerca de The Hifi Match'
                      : 'About The Hifi Match'
                    : modalType === 'contact'
                    ? lang === 'es'
                      ? 'Contacto de Laboratorio'
                      : 'Laboratory Contact'
                    : lang === 'es'
                    ? 'Privacidad y Protección de Datos'
                    : 'Privacy & Data Protection'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setModalType(null)}
                className="text-[#998f83] hover:text-[#e3e2e5]"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <div className="text-sm text-[#d1c5b8] leading-relaxed flex flex-col gap-3 font-body-md">
              {modalType === 'about' && (
                <>
                  <p>
                    {lang === 'es'
                      ? 'The Hifi Match nace como una plataforma de ingeniería electroacústica independiente para erradicar la pseudociencia y la terminología mística del audio de alta fidelidad.'
                      : 'The Hifi Match is an independent electroacoustic engineering platform built to banish pseudoscience and mystic terminology from high-fidelity audio.'}
                  </p>
                  <p>
                    {lang === 'es'
                      ? 'Todos los cálculos de acoplamiento de impedancia, factor EPDR y presión acústica se ejecutan con modelos matemáticos auditables validados bajo las normas IEC 60268-5 y AES-2ID.'
                      : 'All calculations for impedance coupling, EPDR factor and sound pressure levels are run on client-side auditable mathematical models complying with IEC 60268-5 and AES-2ID.'}
                  </p>
                </>
              )}

              {modalType === 'contact' && (
                <>
                  <p>
                    {lang === 'es'
                      ? 'Para someter curvas de laboratorio de nuevos transductores o solicitar calibraciones de recintos acústicos:'
                      : 'To submit laboratory measurement curves for new transducers or request room acoustics calibration:'}
                  </p>
                  <div className="bg-[#0b0c0e] p-3 rounded border border-[#272c35] font-telemetry-sm text-xs text-[#e2c399]">
                    lab@thehifimatch.com <br />
                    AES Member Laboratory ID: #0x88F-AES <br />
                    Madrid / London / Boulder Acoustic Facilities
                  </div>
                </>
              )}

              {modalType === 'privacy' && (
                <>
                  <p>
                    {lang === 'es'
                      ? 'Principios de privacidad absoluta: el 100% de los diagnósticos y simulaciones de sala se ejecutan de manera local en el motor del navegador.'
                      : 'Absolute privacy principle: 100% of all diagnostics and acoustic room simulations are executed locally in the browser.'}
                  </p>
                  <p>
                    {lang === 'es'
                      ? 'No recopilamos cookies de rastreo publicitario ni transmitimos sus especificaciones de sala o equipo a servidores externos.'
                      : 'No ad tracking cookies or personal acoustic room telemetry are transferred to external cloud servers.'}
                  </p>
                </>
              )}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setModalType(null)}
                className="px-4 py-1.5 rounded bg-[#1f2022] hover:bg-[#292a2c] text-[#e3e2e5] font-telemetry-sm text-xs border border-[#4d463c]"
              >
                {lang === 'es' ? 'Cerrar' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
