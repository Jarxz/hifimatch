import React, { useState } from 'react';
import { ScreenTab } from '../types';

interface HeaderProps {
  currentTab: ScreenTab;
  onNavigate: (tab: ScreenTab) => void;
  onReplayBoot: () => void;
  lang: 'es' | 'en';
  onToggleLang: (lang: 'es' | 'en') => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onNavigate,
  onReplayBoot,
  lang,
  onToggleLang,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: ScreenTab; label: string; labelEn: string }[] = [
    { id: 'portada', label: 'Portada', labelEn: 'Overview' },
    { id: 'configurar', label: 'Configurar', labelEn: 'Configure' },
    { id: 'resultado', label: 'Resultado', labelEn: 'Results' },
    { id: 'guia', label: 'Guía', labelEn: 'Physics Guide' },
    { id: 'documento', label: 'Documento (Informe)', labelEn: 'Report (Audit)' },
    { id: 'ar-calibracion', label: 'AR Calibración', labelEn: 'Acoustic Room' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#121315]/95 backdrop-blur-md shadow-[0_1px_8px_rgba(0,0,0,0.6)] border-b border-[#272c35]">
      <div className="w-full px-4 sm:px-6 h-20 flex items-center justify-between gap-4">
        {/* Brand Block */}
        <div
          onClick={() => onNavigate('portada')}
          className="flex items-center gap-3.5 shrink-0 cursor-pointer group"
          id="header-brand-logo"
        >
          <div className="w-9 h-9 bg-[#292a2c] group-hover:bg-[#343537] transition-colors rounded flex items-center justify-center border border-[#e2c399]/20">
            <svg
              className="w-5 h-5 text-[#c5a880]"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.75"
              viewBox="0 0 24 24"
            >
              <path d="M2 12h2M6 8v8M10 5v14M14 9v6M18 4v16M22 12h-2" strokeLinecap="square" />
              <rect
                className="text-[#4d463c]"
                height="20"
                rx="1"
                stroke="currentColor"
                strokeDasharray="2 3"
                width="20"
                x="2"
                y="2"
              />
            </svg>
          </div>
          <div className="flex flex-col">
            <div className="flex items-baseline gap-1.5">
              <span className="font-headline-md tracking-tight text-[#e3e2e5] font-semibold uppercase text-[15px] sm:text-[17px]">
                The Hifi Match
              </span>
              <span className="font-telemetry-sm text-[10px] text-[#e2c399] px-1 rounded bg-[#1f2022] font-semibold">
                SYS.LAB
              </span>
            </div>
            <span className="font-label-caps text-[#d1c5b8] uppercase tracking-widest text-[9px] sm:text-[10px]">
              {lang === 'es' ? 'Física Acústica & Compatibilidad' : 'Acoustic Physics & Compatibility'}
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center gap-6" id="desktop-nav">
          {navItems.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                id={`nav-link-${item.id}`}
                className={`uppercase tracking-wider transition-all py-1 cursor-pointer ${
                  isActive
                    ? 'text-[#e2c399] font-headline-md font-semibold border-b-2 border-[#e2c399]'
                    : 'font-label-caps text-[#d1c5b8] hover:text-[#e3e2e5]'
                }`}
              >
                {lang === 'es' ? item.label : item.labelEn}
              </button>
            );
          })}
        </nav>

        {/* Right Utility Toolbar */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          {/* Replay Boot Sequence Button */}
          <button
            type="button"
            onClick={onReplayBoot}
            id="replay-boot-btn"
            title={lang === 'es' ? 'Reinicializar telemetría de laboratorio' : 'Replay laboratory boot trace'}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#1f2022] hover:bg-[#292a2c] text-[#d1c5b8] hover:text-[#e2c399] transition-all border border-[#4d463c]/40 font-telemetry-sm text-[11px] cursor-pointer"
          >
            <span className="material-symbols-outlined text-[15px] text-[#e2c399]">refresh</span>
            <span>{lang === 'es' ? 'REINICIAR INTRO' : 'RESTART INTRO'}</span>
          </button>

          {/* Epistemological Legend */}
          <div className="hidden 2xl:flex items-center gap-2 px-2.5 py-1 bg-[#0d0e10] rounded border border-[#272c35]">
            <div className="flex items-center gap-1.5 px-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#5ddea9]" />
              <span className="font-telemetry-sm text-[10px] text-[#5ddea9] uppercase">
                {lang === 'es' ? 'Ley Física' : 'Physical Law'}
              </span>
            </div>
            <span className="text-[#4d463c] font-telemetry-sm text-[10px]">/</span>
            <div className="flex items-center gap-1.5 px-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#b6c7e5]" />
              <span className="font-telemetry-sm text-[10px] text-[#b6c7e5] uppercase">
                {lang === 'es' ? 'Criterio' : 'Editorial'}
              </span>
            </div>
          </div>

          {/* Calibrated DB Counter */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 bg-[#1f2022] rounded border border-[#272c35]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#5ddea9] animate-pulse" />
            <span className="font-telemetry-sm text-[11px] text-[#d1c5b8] uppercase">CADENA v2.4</span>
            <span className="font-telemetry-sm text-[10px] text-[#998f83]">[180+ EQ]</span>
          </div>

          {/* Language Switcher */}
          <div className="flex items-center bg-[#0d0e10] rounded p-0.5 border border-[#272c35]">
            <button
              type="button"
              onClick={() => onToggleLang('es')}
              className={`px-2 py-0.5 rounded font-telemetry-sm text-[11px] font-medium transition-colors ${
                lang === 'es'
                  ? 'text-[#e2c399] bg-[#292a2c]'
                  : 'text-[#d1c5b8] hover:text-[#e3e2e5]'
              }`}
            >
              ES
            </button>
            <button
              type="button"
              onClick={() => onToggleLang('en')}
              className={`px-2 py-0.5 rounded font-telemetry-sm text-[11px] font-medium transition-colors ${
                lang === 'en'
                  ? 'text-[#e2c399] bg-[#292a2c]'
                  : 'text-[#d1c5b8] hover:text-[#e3e2e5]'
              }`}
            >
              EN
            </button>
          </div>

          {/* Lab Operator Icon */}
          <div
            title="Lab Operator / Certified Engineer"
            className="w-8 h-8 rounded-full bg-[#e2c399] flex items-center justify-center text-[#402d0f] shadow-sm font-semibold text-xs"
          >
            <span className="material-symbols-outlined text-[18px]">person</span>
          </div>

          {/* Mobile Menu Hamburger */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-1.5 rounded bg-[#1f2022] text-[#e3e2e5] border border-[#272c35]"
            aria-label="Toggle Navigation"
          >
            <span className="material-symbols-outlined text-[20px]">
              {mobileMenuOpen ? 'close' : 'menu'}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#14171c] border-b border-[#272c35] px-6 py-4 flex flex-col gap-3">
          {navItems.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`text-left py-2 px-3 rounded text-sm uppercase tracking-wider font-medium flex items-center justify-between ${
                  isActive
                    ? 'bg-[#1f2022] text-[#e2c399] border-l-2 border-[#e2c399]'
                    : 'text-[#d1c5b8] hover:bg-[#1f2022]'
                }`}
              >
                <span>{lang === 'es' ? item.label : item.labelEn}</span>
                {isActive && <span className="w-1.5 h-1.5 rounded-full bg-[#e2c399]" />}
              </button>
            );
          })}
          <div className="pt-2 border-t border-[#272c35] flex items-center justify-between">
            <button
              type="button"
              onClick={() => {
                onReplayBoot();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-1 text-xs text-[#e2c399]"
            >
              <span className="material-symbols-outlined text-[14px]">refresh</span>
              <span>{lang === 'es' ? 'Reiniciar Intro' : 'Restart Intro'}</span>
            </button>
            <span className="text-[10px] font-telemetry-sm text-[#998f83]">IEC 60268-5 / AES-2ID</span>
          </div>
        </div>
      )}
    </header>
  );
};
