import React, { useEffect, useState, useRef } from 'react';

interface BootSplashProps {
  isOpen: boolean;
  onDismiss: () => void;
}

export const BootSplash: React.FC<BootSplashProps> = ({ isOpen, onDismiss }) => {
  const [progress, setProgress] = useState(0);
  const [step1State, setStep1State] = useState<'pending' | 'active' | 'ok'>('active');
  const [step2State, setStep2State] = useState<'queue' | 'active' | 'ok'>('queue');
  const [step3State, setStep3State] = useState<'queue' | 'active' | 'ok'>('queue');
  const animRef = useRef<number | null>(null);
  const startTimeRef = useRef<number | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    setProgress(0);
    setStep1State('active');
    setStep2State('queue');
    setStep3State('queue');
    startTimeRef.current = null;

    const duration = 2100; // 2.1s duration matching spec

    const tick = (timestamp: number) => {
      if (!startTimeRef.current) startTimeRef.current = timestamp;
      const elapsed = timestamp - startTimeRef.current;
      const ratio = Math.min(elapsed / duration, 1);
      // Cubic ease out
      const eased = 1 - Math.pow(1 - ratio, 2.5);
      const pct = Math.floor(eased * 100);
      setProgress(pct);

      if (ratio >= 0.35 && ratio < 0.72) {
        setStep1State('ok');
        setStep2State('active');
      } else if (ratio >= 0.72 && ratio < 0.96) {
        setStep1State('ok');
        setStep2State('ok');
        setStep3State('active');
      } else if (ratio >= 0.96) {
        setStep1State('ok');
        setStep2State('ok');
        setStep3State('ok');
      }

      if (ratio < 1) {
        animRef.current = requestAnimationFrame(tick);
      } else {
        setTimeout(() => {
          onDismiss();
        }, 300);
      }
    };

    animRef.current = requestAnimationFrame(tick);

    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [isOpen, onDismiss]);

  if (!isOpen) return null;

  return (
    <div
      id="boot-splash"
      className="fixed inset-0 z-[100] flex flex-col justify-between bg-[#0b0c0e] text-[#e3e2e5] select-none transition-opacity duration-500 ease-out"
    >
      {/* Dynamic Acoustic Wireframe Vector Matrix */}
      <div className="absolute inset-0 pointer-events-none opacity-25 overflow-hidden flex items-center justify-center">
        <svg
          className="w-[1200px] h-[800px] text-[#e2c399]"
          fill="none"
          viewBox="0 0 1000 600"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Grid Calibration Axes */}
          <line
            className="opacity-40"
            stroke="currentColor"
            strokeDasharray="2 4"
            strokeWidth="0.75"
            x1="100"
            x2="900"
            y1="300"
            y2="300"
          />
          <line
            className="opacity-40"
            stroke="currentColor"
            strokeDasharray="2 4"
            strokeWidth="0.75"
            x1="500"
            x2="500"
            y1="50"
            y2="550"
          />
          <circle
            className="opacity-30 animate-wave"
            cx="500"
            cy="300"
            r="140"
            stroke="currentColor"
            strokeDasharray="4 8"
            strokeWidth="0.75"
          />
          <circle
            className="opacity-20 animate-wave"
            cx="500"
            cy="300"
            r="260"
            stroke="currentColor"
            strokeDasharray="3 6"
            strokeWidth="0.5"
          />
          {/* Simulated Complex Impedance & Phase Vector Paths */}
          <path
            className="animate-dash"
            d="M120 420 C220 440, 280 180, 360 210 C440 240, 480 390, 540 370 C620 340, 680 160, 780 220 C840 260, 880 320, 920 310"
            stroke="#e2c399"
            strokeLinecap="round"
            strokeWidth="2"
          />
          <path
            className="animate-dash opacity-70"
            d="M120 280 C240 250, 340 360, 460 320 C540 290, 640 420, 740 360 C820 310, 880 230, 920 240"
            stroke="#5ddea9"
            strokeDasharray="4 4"
            strokeLinecap="round"
            strokeWidth="1.2"
          />
          {/* Mode Nodes */}
          <circle cx="360" cy="210" fill="#e2c399" r="4" />
          <circle cx="540" cy="370" fill="#5ddea9" r="4" />
          <circle cx="780" cy="220" fill="#b6c7e5" r="4" />
          <text className="font-telemetry-sm text-[10px]" fill="#e2c399" x="375" y="215">
            Z_min: 3.2Ω @ 142Hz
          </text>
          <text className="font-telemetry-sm text-[10px]" fill="#5ddea9" x="555" y="375">
            θ_crit: -42.8°
          </text>
          <text className="font-telemetry-sm text-[10px]" fill="#b6c7e5" x="795" y="225">
            EPDR: 1.8Ω
          </text>
        </svg>
      </div>

      {/* Splash Top Bar: Engine Status */}
      <div className="relative z-10 w-full px-6 py-3 flex items-center justify-between border-b border-[#343537]/40 bg-[#0b0c0e]/80 backdrop-blur-sm">
        <div className="flex items-center gap-2 font-telemetry-sm text-[11px]">
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#1f2022] text-[#e2c399]">
            <span className="w-2 h-2 rounded-full bg-[#5ddea9] animate-ping" />
            MOTOR CADENA v2.4.0
          </span>
          <span className="text-[#4d463c]">|</span>
          <span className="text-[#d1c5b8] uppercase tracking-wider hidden sm:inline">
            INICIALIZACIÓN DETERMINISTA
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="font-telemetry-sm text-[11px] text-[#998f83] hidden md:inline">
            IEC 60268-5 / AES-2ID
          </span>
          <button
            id="skip-intro-btn"
            type="button"
            onClick={onDismiss}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-[#292a2c] hover:bg-[#38393b] text-[#e3e2e5] font-telemetry-sm text-[11px] transition-colors cursor-pointer border border-[#4d463c]/50"
          >
            <span>SALTAR INTRO</span>
            <span className="material-symbols-outlined text-[16px] text-[#e2c399]">fast_forward</span>
          </button>
        </div>
      </div>

      {/* Splash Center Console: Logo & Boot Telemetry */}
      <div className="relative z-10 max-w-2xl mx-auto w-full px-4 flex flex-col items-center justify-center my-auto text-center gap-6">
        {/* Emblem */}
        <div className="w-16 h-16 bg-[#292a2c] rounded-xl border border-[#e2c399]/30 flex items-center justify-center shadow-[0_0_30px_rgba(226,195,153,0.15)] mb-1">
          <svg className="w-8 h-8 text-[#e2c399]" fill="none" stroke="currentColor" strokeWidth="1.75" viewBox="0 0 24 24">
            <path d="M2 12h2M6 8v8M10 5v14M14 9v6M18 4v16M22 12h-2" strokeLinecap="square" />
            <rect className="text-[#4d463c]" height="20" rx="1" stroke="currentColor" strokeDasharray="2 3" width="20" x="2" y="2" />
          </svg>
        </div>

        {/* Central Title Block */}
        <div className="flex flex-col items-center gap-1">
          <div className="flex items-baseline gap-2 justify-center">
            <h1 className="font-headline-xl text-3xl sm:text-4xl lg:text-5xl uppercase font-bold tracking-tight text-[#e3e2e5]">
              The Hifi <span className="text-[#e2c399]">Match</span>
            </h1>
            <span className="font-telemetry-sm text-[11px] text-[#5ddea9] px-2 py-0.5 rounded bg-[#1f2022] font-medium">
              SYS.LAB
            </span>
          </div>
          <p className="font-label-caps text-[#d1c5b8] uppercase tracking-[0.2em]">
            MOTOR DE EVALUACIÓN ELECTROACÚSTICA // IEC 60268-5
          </p>
        </div>

        {/* Progress Meter & Live Status */}
        <div className="w-full bg-[#1b1c1e] border border-[#343537]/60 rounded p-4 flex flex-col gap-3 text-left shadow-2xl">
          <div className="flex items-center justify-between font-telemetry-sm text-[11px]">
            <span className="text-[#998f83] flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#e2c399] animate-pulse" />
              DIAGNÓSTICO DEL SISTEMA
            </span>
            <span className="text-[#e2c399] font-bold">{progress}%</span>
          </div>

          {/* Linear Micro Progress Gauge */}
          <div className="w-full h-2 rounded bg-[#0d0e10] overflow-hidden border border-[#4d463c]/30">
            <div
              className="h-full bg-gradient-to-r from-[#c5a880] via-[#e2c399] to-[#5ddea9] transition-all duration-100 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>

          {/* Realtime Boot Trace Steps */}
          <div className="flex flex-col gap-1.5 font-telemetry-sm text-[11px] pt-1 text-[#d1c5b8]/90">
            <div
              className={`flex items-center justify-between py-1.5 px-2.5 rounded bg-[#0d0e10]/60 border-l-2 transition-all ${
                step1State === 'ok'
                  ? 'border-[#5ddea9] bg-[#1f2022]/60'
                  : 'border-[#e2c399]'
              }`}
            >
              <span className="truncate">Cargando biblioteca de transductores (182 modelos medidos)...</span>
              <span
                className={`font-medium text-[11px] shrink-0 ml-2 ${
                  step1State === 'ok'
                    ? 'text-[#5ddea9]'
                    : 'text-[#e2c399] animate-pulse'
                }`}
              >
                {step1State === 'ok' ? '[OK]' : 'PROCESANDO...'}
              </span>
            </div>

            <div
              className={`flex items-center justify-between py-1.5 px-2.5 rounded bg-[#0d0e10]/60 border-l-2 transition-all ${
                step2State === 'ok'
                  ? 'border-[#5ddea9] bg-[#1f2022]/60'
                  : step2State === 'active'
                  ? 'border-[#e2c399]'
                  : 'border-transparent opacity-40'
              }`}
            >
              <span className="truncate">Compilando ecuaciones deterministas de recintos (Sabine/Eyring)...</span>
              <span
                className={`font-medium text-[11px] shrink-0 ml-2 ${
                  step2State === 'ok'
                    ? 'text-[#5ddea9]'
                    : step2State === 'active'
                    ? 'text-[#e2c399] animate-pulse'
                    : 'text-[#998f83]'
                }`}
              >
                {step2State === 'ok' ? '[OK]' : step2State === 'active' ? 'COMPILANDO...' : '[EN COLA]'}
              </span>
            </div>

            <div
              className={`flex items-center justify-between py-1.5 px-2.5 rounded bg-[#0d0e10]/60 border-l-2 transition-all ${
                step3State === 'ok'
                  ? 'border-[#5ddea9] bg-[#1f2022]/60'
                  : step3State === 'active'
                  ? 'border-[#e2c399]'
                  : 'border-transparent opacity-40'
              }`}
            >
              <span className="truncate">Iniciando aislamiento estricto: Ley física vs. Criterio editorial...</span>
              <span
                className={`font-medium text-[11px] shrink-0 ml-2 ${
                  step3State === 'ok'
                    ? 'text-[#5ddea9]'
                    : step3State === 'active'
                    ? 'text-[#e2c399] animate-pulse'
                    : 'text-[#998f83]'
                }`}
              >
                {step3State === 'ok' ? '[OK]' : step3State === 'active' ? 'AISLANDO...' : '[EN COLA]'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Splash Bottom Bar: Epistemological Disclaimer */}
      <div className="relative z-10 w-full px-6 py-2.5 flex flex-col sm:flex-row items-center justify-between gap-1 border-t border-[#343537]/40 bg-[#0b0c0e]/80 text-[#998f83] font-telemetry-sm text-[11px]">
        <div className="flex items-center gap-2">
          <span className="text-[#5ddea9]">●</span>
          <span>ARQUITECTURA DETERMINISTA Y MEDICIONES FÍSICAS AUDITABLES</span>
        </div>
        <div className="flex items-center gap-1">
          <span>CALIBRADO BAJO LEYES ELECTROACÚSTICAS REFUTABLES</span>
        </div>
      </div>
    </div>
  );
};
